<?php
require_once __DIR__ . '/../config/cors.php'; require_once __DIR__ . '/../config/db.php';
$pdo->exec('CREATE TABLE IF NOT EXISTS faqs (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question VARCHAR(255) NOT NULL, answer TEXT NOT NULL, asked_by VARCHAR(150) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB'); try{$pdo->exec('ALTER TABLE faqs ADD COLUMN asked_by VARCHAR(150) NULL');}catch(Throwable $e){}
echo json_encode(['faqs'=>$pdo->query('SELECT * FROM faqs ORDER BY id DESC')->fetchAll()]);
