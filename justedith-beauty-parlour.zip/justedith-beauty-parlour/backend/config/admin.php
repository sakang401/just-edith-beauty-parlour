<?php
require_once __DIR__ . '/cors.php';
$ADMIN_PIN = '1234'; // Change this before deploying publicly.
function requireAdmin(): void {
    global $ADMIN_PIN;
    $pin = $_SERVER['HTTP_X_ADMIN_PIN'] ?? '';
    if (!hash_equals($ADMIN_PIN, $pin)) {
        http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Admin authentication required.']);
        exit;
    }
}
?>
