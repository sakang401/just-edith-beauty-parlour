<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
requireAdmin();
function adminResponse($data, $code=200) {
  http_response_code($code); echo json_encode($data); exit;
}
function body() { return getJsonBody(); }

$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){
 $rows=$pdo->query("SELECT * FROM services ORDER BY category,name")->fetchAll();
 adminResponse(['success'=>true,'services'=>$rows]);
}
$d=body();
if($method==='POST'){
 $s=$pdo->prepare("INSERT INTO services(category,name,price,price_label,description,active) VALUES(?,?,?,?,?,?)");
 $s->execute([cleanString($d['category']??''),cleanString($d['name']??''),(float)($d['price']??0),cleanString($d['price_label']??''),cleanString($d['description']??''),(int)($d['active']??1)]);
 adminResponse(['success'=>true,'id'=>$pdo->lastInsertId()]);
}
if($method==='PUT'){
 $s=$pdo->prepare("UPDATE services SET category=?,name=?,price=?,price_label=?,description=?,active=? WHERE id=?");
 $s->execute([cleanString($d['category']??''),cleanString($d['name']??''),(float)($d['price']??0),cleanString($d['price_label']??''),cleanString($d['description']??''),(int)($d['active']??1),(int)($d['id']??0)]);
 adminResponse(['success'=>true]);
}
if($method==='DELETE'){
 $s=$pdo->prepare("DELETE FROM services WHERE id=?"); $s->execute([(int)($d['id']??0)]);
 adminResponse(['success'=>true]);
}
adminResponse(['success'=>false,'message'=>'Method not allowed'],405);
