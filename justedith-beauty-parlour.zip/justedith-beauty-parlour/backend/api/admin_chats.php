<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
require_once __DIR__ . '/notify.php';
requireAdmin();
if ($_SERVER['REQUEST_METHOD']==='GET') {
  $bookingId=(int)($_GET['booking_id']??0);
  if($bookingId>0){ $q=$pdo->prepare('SELECT id,sender,message,image_path,created_at FROM chat_messages WHERE booking_id=? ORDER BY created_at ASC'); $q->execute([$bookingId]); echo json_encode(['success'=>true,'messages'=>$q->fetchAll()]); exit; }
  $sql="SELECT b.id,b.name,b.phone,b.service,b.appointment_date,b.appointment_time,b.status,
    (SELECT COUNT(*) FROM chat_messages cm WHERE cm.booking_id=b.id) message_count,
    (SELECT MAX(cm2.created_at) FROM chat_messages cm2 WHERE cm2.booking_id=b.id) last_message,
    (SELECT cm3.sender FROM chat_messages cm3 WHERE cm3.booking_id=b.id ORDER BY cm3.created_at DESC, cm3.id DESC LIMIT 1) last_sender
    FROM bookings b WHERE EXISTS (SELECT 1 FROM chat_messages x WHERE x.booking_id=b.id)
    ORDER BY last_message DESC";
  echo json_encode(['success'=>true,'chats'=>$pdo->query($sql)->fetchAll()]); exit;
}
if ($_SERVER['REQUEST_METHOD']==='PUT') {
  $d=getJsonBody(); $bookingId=(int)($d['booking_id']??0); $reply=cleanString($d['reply']??'');
  if($bookingId<1||$reply===''){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Booking ID and reply are required.']);exit;}
  $lookup=$pdo->prepare('SELECT user_id FROM bookings WHERE id=?'); $lookup->execute([$bookingId]); $uid=(int)$lookup->fetchColumn();
  $s=$pdo->prepare("INSERT INTO chat_messages(booking_id,sender,message) VALUES(?, 'provider', ?)"); $s->execute([$bookingId,$reply]);
  if($uid) notifyUser($pdo,$uid,'New message from Just Edith','You have a new reply in your private style chat.','chat');
  echo json_encode(['success'=>true,'message'=>'Reply sent.']); exit;
}
http_response_code(405); echo json_encode(['success'=>false,'message'=>'Method not allowed']);
?>
