<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notify.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => false]);
session_start();

$servicePrices = [
    'Knotless Braids' => 600,
    'Boho Knotless' => 600,
    'Boho Twists' => 1000,
    'Coco Twists' => 800,
    'Classic' => 400,
    'Hybrid' => 700,
    'Volume' => 1000,
    'Lash Removal' => 100,
];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT id, user_id, name, phone, service, appointment_date, appointment_time, notes, service_price, deposit_amount, mpesa_receipt, payment_status, status, created_at FROM bookings ORDER BY appointment_date ASC, appointment_time ASC");
    echo json_encode(['success' => true, 'bookings' => $stmt->fetchAll()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please register or log in before booking.']);
    exit;
}

$data = getJsonBody();
$service = cleanString($data['service'] ?? '');
$date = cleanString($data['date'] ?? '');
$time = cleanString($data['time'] ?? '');
$notes = cleanString($data['notes'] ?? '');
$mpesaReceipt = strtoupper(cleanString($data['mpesa_receipt'] ?? ''));
$paidAmount = (float)($data['paid_amount'] ?? 0);

if (!isset($servicePrices[$service])) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please select a valid service.']);
    exit;
}

$stmtUser = $pdo->prepare("SELECT full_name, phone FROM users WHERE id = ?");
$stmtUser->execute([$_SESSION['user_id']]);
$user = $stmtUser->fetch();

if (!$user) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Your account could not be found. Please log in again.']);
    exit;
}

if ($date === '' || $time === '' || $mpesaReceipt === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Appointment date, time and M-Pesa transaction code are required.']);
    exit;
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !preg_match('/^\d{2}:\d{2}$/', $time)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please use a valid appointment date and time.']);
    exit;
}

$servicePrice = $servicePrices[$service];
$requiredDeposit = $servicePrice / 2;

if (abs($paidAmount - $requiredDeposit) > 0.01) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => 'The required booking deposit is KSh ' . number_format($requiredDeposit, 2) . ' (50% of the listed starting price).'
    ]);
    exit;
}

$chatToken = bin2hex(random_bytes(32));
$stmt = $pdo->prepare("INSERT INTO bookings (user_id, name, phone, service, appointment_date, appointment_time, notes, chat_token, service_price, deposit_amount, mpesa_receipt, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_verification')");
$stmt->execute([
    $_SESSION['user_id'], $user['full_name'], $user['phone'], $service, $date, $time, $notes,
    $chatToken, $servicePrice, $requiredDeposit, $mpesaReceipt
]);
$bookingId = (int)$pdo->lastInsertId();
notifyAdmin($pdo, 'New appointment request', 'A new booking request was submitted for ' . $user['full_name'] . ' — ' . $service . '.', 'booking');
notifyUser($pdo, (int)$_SESSION['user_id'], 'Booking received', 'Your appointment request has been received and is awaiting confirmation.', 'booking');

echo json_encode([
    'success' => true,
    'message' => 'Booking request received. M-Pesa payment is pending verification.',
    'booking_id' => $bookingId,
    'chat_token' => $chatToken,
    'required_deposit' => $requiredDeposit,
    'payment_status' => 'pending_verification'
]);
?>