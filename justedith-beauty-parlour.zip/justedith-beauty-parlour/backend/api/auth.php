<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notify.php';

session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Lax',
    'secure' => false
]);
session_start();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if (!empty($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("SELECT id, full_name, email, phone, profile_image, created_at FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            echo json_encode(['success' => true, 'authenticated' => true, 'user' => $user]);
            exit;
        }
    }
    echo json_encode(['success' => true, 'authenticated' => false, 'user' => null]);
    exit;
}

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$action = cleanString($_POST['action'] ?? '');
$uploadDir = __DIR__ . '/../uploads/profiles/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

function profileImageUrl($filename) {
    return $filename ? '/justedith-beauty-parlour/backend/uploads/profiles/' . rawurlencode(basename($filename)) : null;
}

if ($action === 'register') {
    $name = cleanString($_POST['full_name'] ?? '');
    $email = strtolower(cleanString($_POST['email'] ?? ''));
    $phone = cleanString($_POST['phone'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($name === '' || $email === '' || $phone === '' || $password === '') {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Please complete all registration fields.']);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
        exit;
    }
    if (strlen($password) < 8) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters.']);
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'An account with this email already exists.']);
        exit;
    }

    $imageName = null;
    if (!empty($_FILES['profile_image']['name'])) {
        $file = $_FILES['profile_image'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Profile image upload failed.']);
            exit;
        }
        if ($file['size'] > 5 * 1024 * 1024) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Profile image must be 5MB or smaller.']);
            exit;
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowed[$mime])) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Use JPG, PNG or WEBP for your profile image.']);
            exit;
        }
        $imageName = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
        move_uploaded_file($file['tmp_name'], $uploadDir . $imageName);
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, profile_image) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $phone, $hash, $imageName]);
    $_SESSION['user_id'] = (int)$pdo->lastInsertId();

    notifyAdmin($pdo, 'New user registered', $name . ' created a new customer account.', 'user');

    echo json_encode([
        'success' => true,
        'message' => 'Account created successfully.',
        'user' => [
            'id' => $_SESSION['user_id'],
            'full_name' => $name,
            'email' => $email,
            'phone' => $phone,
            'profile_image' => profileImageUrl($imageName)
        ]
    ]);
    exit;
}

if ($action === 'login') {
    $email = strtolower(cleanString($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $stmt = $pdo->prepare("SELECT id, full_name, email, phone, password_hash, profile_image FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Incorrect email or password.']);
        exit;
    }

    $loginImage = null;
    if (!empty($_FILES['profile_image']['name'])) {
        $file=$_FILES['profile_image'];
        if ($file['error'] === UPLOAD_ERR_OK && $file['size'] <= 5*1024*1024) {
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (isset($allowed[$mime])) {
                $loginImage=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
                move_uploaded_file($file['tmp_name'],$uploadDir.$loginImage);
                if (!empty($user['profile_image']) && is_file($uploadDir.basename($user['profile_image']))) @unlink($uploadDir.basename($user['profile_image']));
                $up=$pdo->prepare('UPDATE users SET profile_image=? WHERE id=?'); $up->execute([$loginImage,$user['id']]);
                $user['profile_image']=$loginImage;
            }
        }
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    unset($user['password_hash']);
    $user['profile_image'] = profileImageUrl($user['profile_image']);

    echo json_encode(['success' => true, 'message' => 'Welcome back.', 'user' => $user]);
    exit;
}


if ($action === 'update_profile') {
    if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['success'=>false,'message'=>'Please log in first.']); exit; }
    $name = cleanString($_POST['full_name'] ?? '');
    $phone = cleanString($_POST['phone'] ?? '');
    if ($name === '' || $phone === '') { http_response_code(422); echo json_encode(['success'=>false,'message'=>'Name and phone are required.']); exit; }
    $imageName = null;
    if (!empty($_FILES['profile_image']['name'])) {
        $file=$_FILES['profile_image'];
        if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5*1024*1024) { http_response_code(422); echo json_encode(['success'=>false,'message'=>'Profile image must be 5MB or smaller.']); exit; }
        $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']);
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if (!isset($allowed[$mime])) { http_response_code(422); echo json_encode(['success'=>false,'message'=>'Use JPG, PNG or WEBP.']); exit; }
        $imageName=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
        if (!move_uploaded_file($file['tmp_name'],$uploadDir.$imageName)) { http_response_code(500); echo json_encode(['success'=>false,'message'=>'Could not save profile image.']); exit; }
    }
    if ($imageName) {
        $old=$pdo->prepare('SELECT profile_image FROM users WHERE id=?'); $old->execute([$_SESSION['user_id']]); $oldName=$old->fetchColumn();
        $stmt=$pdo->prepare('UPDATE users SET full_name=?, phone=?, profile_image=? WHERE id=?'); $stmt->execute([$name,$phone,$imageName,$_SESSION['user_id']]);
        if ($oldName && is_file($uploadDir.basename($oldName))) @unlink($uploadDir.basename($oldName));
    } else {
        $stmt=$pdo->prepare('UPDATE users SET full_name=?, phone=? WHERE id=?'); $stmt->execute([$name,$phone,$_SESSION['user_id']]);
    }
    $stmt=$pdo->prepare('SELECT id,full_name,email,phone,profile_image FROM users WHERE id=?'); $stmt->execute([$_SESSION['user_id']]); $u=$stmt->fetch(); $u['profile_image']=profileImageUrl($u['profile_image']);
    echo json_encode(['success'=>true,'message'=>'Profile updated.','user'=>$u]); exit;
}

if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Logged out.']);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Unknown authentication action.']);
?>