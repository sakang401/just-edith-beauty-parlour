<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
requireAdmin();
function adminResponse($data, $code=200) {
  http_response_code($code); echo json_encode($data); exit;
}
function body() { return getJsonBody(); }
