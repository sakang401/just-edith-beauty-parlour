<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/provider.php';

requireProvider();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $bookingId = (int)($_GET['booking_id'] ?? 0);
    if ($bookingId > 0) {
        $stmt = $pdo->prepare("SELECT id, sender, message, image_path, created_at FROM chat_messages WHERE booking_id = ? ORDER BY created_at ASC");
        $stmt->execute([$bookingId]);
        echo json_encode(['success' => true, 'messages' => $stmt->fetchAll()]);
        exit;
    }

    $stmt = $pdo->query("SELECT b.id, b.name, b.phone, b.service, b.appointment_date, b.appointment_time, b.status, (SELECT COUNT(*) FROM chat_messages cm WHERE cm.booking_id = b.id) AS message_count FROM bookings b WHERE EXISTS (SELECT 1 FROM chat_messages cm2 WHERE cm2.booking_id = b.id) ORDER BY (SELECT MAX(cm3.created_at) FROM chat_messages cm3 WHERE cm3.booking_id = b.id) DESC");
    echo json_encode(['success' => true, 'conversations' => $stmt->fetchAll()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$data = getJsonBody();
$bookingId = (int)($data['booking_id'] ?? 0);
$message = cleanString($data['message'] ?? '');

if ($bookingId < 1 || $message === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Booking ID and reply are required.']);
    exit;
}

$stmt = $pdo->prepare("SELECT id FROM bookings WHERE id = ? LIMIT 1");
$stmt->execute([$bookingId]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Booking not found.']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO chat_messages (booking_id, sender, message) VALUES (?, 'provider', ?)");
$stmt->execute([$bookingId, $message]);

echo json_encode(['success' => true, 'message' => 'Reply sent.']);
?>
