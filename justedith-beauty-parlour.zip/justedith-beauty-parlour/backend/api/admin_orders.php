<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../config/admin.php'; require_once __DIR__.'/notify.php'; requireAdmin();
function adminOrderResponse($data,$code=200){http_response_code($code);echo json_encode($data);exit;}
if($_SERVER['REQUEST_METHOD']==='GET'){
 $sql="SELECT o.id,o.user_id,o.total_amount,o.payment_method,o.payment_status,o.mpesa_receipt,o.status,o.created_at,u.full_name,u.phone,(SELECT GROUP_CONCAT(CONCAT(oi.title,' × ',oi.quantity) ORDER BY oi.id SEPARATOR ', ') FROM order_items oi WHERE oi.order_id=o.id) item_summary FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC";
 adminOrderResponse(['success'=>true,'orders'=>$pdo->query($sql)->fetchAll()]);
}
if($_SERVER['REQUEST_METHOD']==='PUT'){
 $d=getJsonBody();$id=(int)($d['id']??0);if($id<1)adminOrderResponse(['success'=>false,'message'=>'A valid order ID is required.'],422);
 $q=$pdo->prepare('SELECT user_id FROM orders WHERE id=?');$q->execute([$id]);$uid=$q->fetchColumn();if(!$uid)adminOrderResponse(['success'=>false,'message'=>'Order not found.'],404);
 if(isset($d['status'])){ $st=cleanString($d['status']); if(!in_array($st,['pending','processing','completed','cancelled'],true))adminOrderResponse(['success'=>false,'message'=>'Invalid order status.'],422); $pdo->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$st,$id]); notifyUser($pdo,(int)$uid,'Order status updated','Your store order #'.$id.' is now '.$st.'.','order'); }
 if(isset($d['payment_status'])){ $ps=cleanString($d['payment_status']); if(!in_array($ps,['pending','paid','failed'],true))adminOrderResponse(['success'=>false,'message'=>'Invalid payment status.'],422); $pdo->prepare('UPDATE orders SET payment_status=? WHERE id=?')->execute([$ps,$id]); notifyUser($pdo,(int)$uid,'Order payment updated','Payment for store order #'.$id.' is now '.$ps.'.','order'); }
 adminOrderResponse(['success'=>true]);
}
adminOrderResponse(['success'=>false,'message'=>'Method not allowed'],405);
