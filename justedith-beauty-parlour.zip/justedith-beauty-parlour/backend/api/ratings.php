<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $service = cleanString($_GET['service'] ?? '');

    // With no service selected, return an accumulated summary for every service.
    // This lets the service cards show their own live average and review count.
    if ($service === '') {
        $stmt = $pdo->query("SELECT service, ROUND(AVG(rating), 1) AS average_rating, COUNT(*) AS total_reviews
                             FROM service_ratings
                             GROUP BY service");
        echo json_encode(['success' => true, 'summaries' => $stmt->fetchAll()]);
        exit;
    }

    $stmt = $pdo->prepare("SELECT customer_name, rating, review, created_at
                           FROM service_ratings
                           WHERE service = ?
                           ORDER BY created_at DESC LIMIT 30");
    $stmt->execute([$service]);
    $reviews = $stmt->fetchAll();

    // Average and count are calculated over ALL ratings for the service,
    // not just the reviews displayed on the page.
    $avgStmt = $pdo->prepare("SELECT ROUND(AVG(rating), 1) AS average_rating, COUNT(*) AS total_reviews
                              FROM service_ratings WHERE service = ?");
    $avgStmt->execute([$service]);
    $summary = $avgStmt->fetch() ?: ['average_rating' => null, 'total_reviews' => 0];

    echo json_encode(['success' => true, 'summary' => $summary, 'reviews' => $reviews]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$data = getJsonBody();
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'message'=>'Please log in to submit a rating.']);exit;}
$nameStmt=$pdo->prepare('SELECT full_name FROM users WHERE id=?');$nameStmt->execute([(int)$_SESSION['user_id']]);$loggedName=(string)$nameStmt->fetchColumn();
$service = cleanString($data['service'] ?? '');
$customer = $loggedName;
$rating = (int)($data['rating'] ?? 0);
$review = cleanString($data['review'] ?? '');

if ($service === '' || $customer === '' || $rating < 1 || $rating > 5) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please select a service, enter your name and choose 1–5 stars.']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO service_ratings (service, customer_name, rating, review) VALUES (?, ?, ?, ?)");
$stmt->execute([$service, $customer, $rating, $review]);

echo json_encode(['success' => true, 'message' => 'Thank you! Your service rating has been posted.']);
?>
