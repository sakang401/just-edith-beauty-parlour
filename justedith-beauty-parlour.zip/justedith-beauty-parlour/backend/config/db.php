<?php
// XAMPP default MySQL configuration.
// Change these values if your local MySQL setup uses a password.
$host = '127.0.0.1';
$db   = 'justedith_beauty';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed. Check XAMPP MySQL and backend/config/db.php.']);
    exit;
}
// Lightweight compatibility migrations for existing XAMPP installations.
try {
    $pdo->exec("ALTER TABLE services ADD COLUMN IF NOT EXISTS image_url VARCHAR(500) NULL");
    $pdo->exec("INSERT IGNORE INTO store_settings(setting_key,setting_value) VALUES ('home_background','')");
} catch (Throwable $e) { /* Fresh schema already contains these fields. */ }
?>