<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../config/admin.php'; requireAdmin();
if($_SERVER['REQUEST_METHOD']==='GET'){$rows=$pdo->query("SELECT id,title,message,type,is_read,created_at FROM notifications WHERE audience='admin' ORDER BY created_at DESC LIMIT 100")->fetchAll();echo json_encode(['success'=>true,'notifications'=>$rows]);exit;}
if($_SERVER['REQUEST_METHOD']==='PUT'){$d=json_decode(file_get_contents('php://input'),true)?:[];if(!empty($d['all']))$pdo->exec("UPDATE notifications SET is_read=1 WHERE audience='admin'");elseif(isset($d['id'])){$s=$pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND audience='admin'");$s->execute([(int)$d['id']]);}echo json_encode(['success'=>true]);exit;}
http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);
