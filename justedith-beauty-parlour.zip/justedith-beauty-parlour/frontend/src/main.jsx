import React, { useEffect, useState, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { submitBooking, submitContact, submitRating, getRatings, sendChatMessage, getChat, getCurrentUser, logoutUser, updateProfile, getStorePhotos, getNotifications, markNotificationRead, markAllNotificationsRead, getWallet, checkoutStore, mediaUrl, getServices } from './api';
import { LoginPage, RegisterPage } from './auth';
import ProviderApp from './provider';
import Admin from './admin';
import './styles.css';

const services = [
  { category: 'Braids & Twists', name: 'Knotless Braids', price: 'KSh 600', note: 'Classic, neat and effortlessly chic.' },
  { category: 'Braids & Twists', name: 'Boho Knotless', price: 'From KSh 600', note: 'Soft curls, texture and luxe movement.' },
  { category: 'Braids & Twists', name: 'Boho Twists', price: 'From KSh 1,000', note: 'Statement twists with a beautiful finish.' },
  { category: 'Braids & Twists', name: 'Coco Twists', price: 'From KSh 800', note: 'Polished protective styling with attitude.' },
  { category: 'Lashes', name: 'Classic', price: 'KSh 400', note: 'Natural definition for everyday glam.' },
  { category: 'Lashes', name: 'Hybrid', price: 'KSh 700', note: 'The perfect balance of soft and bold.' },
  { category: 'Lashes', name: 'Volume', price: 'KSh 1,000', note: 'Fuller, dramatic and unapologetically luxe.' },
  { category: 'Lashes', name: 'Lash Removal', price: 'KSh 100', note: 'Gentle, careful removal.' },
];


const Icon=({name,size=18})=>{const paths={cart:<><path d="M3 4h2l1.6 10.2a2 2 0 0 0 2 1.8h7.9a2 2 0 0 0 2-1.7L20 7H6"/><circle cx="9" cy="20" r="1"/><circle cx="17" cy="20" r="1"/></>,minus:<path d="M5 12h14"/>,plus:<><path d="M12 5v14"/><path d="M5 12h14"/></>,trash:<><path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M7 7l1 13h8l1-13M9 7V4h6v3"/></>,bell:<><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,whatsapp:<path d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4.1A8 8 0 1 1 20 11.5Z"/>,wallet:<><path d="M3 7h16a2 2 0 0 1 2 2v9H5a2 2 0 0 1-2-2V7Z"/><path d="M3 7V5a2 2 0 0 1 2-2h13v4"/><path d="M16 13h3"/></>,card:<><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/></>}; return <svg className="ui-icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>};

const extras = [
  ['Extra-long', '+KSh 200'],
  ['Boho curls', '+KSh 200'],
  ['Custom styles', '+KSh 100'],
];

function ProfilePage({ user, onUser }) {
  const [form,setForm]=useState({full_name:user?.full_name||'',phone:user?.phone||'',profile_image:null});
  const [status,setStatus]=useState('');
  if(!user) return <div className="auth-loading">Please <a href="/login">log in</a> first.</div>;
  async function save(e){e.preventDefault();setStatus('Saving…');const fd=new FormData();fd.append('action','update_profile');fd.append('full_name',form.full_name);fd.append('phone',form.phone);if(form.profile_image)fd.append('profile_image',form.profile_image);try{const r=await updateProfile(fd);onUser(r.user);setStatus('✨ Profile updated successfully.');}catch(err){setStatus(err.message)}}
  return <div className="auth-page"><div className="auth-brand"><a href="/"><img src="/logo.png" alt="Just Edith"/></a></div><div className="auth-panel"><div className="profile-page-hero"><div className="profile-top-avatar">{form.profile_image?<img src={URL.createObjectURL(form.profile_image)} alt="Profile preview"/>:user.profile_image?<img src={mediaUrl(user.profile_image)} alt={user.full_name} onError={e=>{e.currentTarget.style.display="none";e.currentTarget.nextElementSibling.style.display="grid"}}/>:null}<span style={{display:(form.profile_image||user.profile_image)?"none":"grid"}}>{user.full_name?.charAt(0)?.toUpperCase()}</span></div><div><p className="eyebrow">YOUR JUST EDITH PROFILE</p><h1>{user.full_name?.split(" ")[0] || "Your"} <em>profile.</em></h1><p>Manage your details and profile photo.</p></div></div><form className="auth-form" onSubmit={save}><div className="avatar-preview">{form.profile_image?<img src={URL.createObjectURL(form.profile_image)} alt="Preview"/>:user.profile_image?<img src={mediaUrl(user.profile_image)} alt={user.full_name} onError={e=>{e.currentTarget.style.display="none";e.currentTarget.nextElementSibling.style.display="grid"}}/>:<span>{user.full_name?.charAt(0)?.toUpperCase()}</span>}</div><label>Profile image<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setForm({...form,profile_image:e.target.files?.[0]||null})}/></label><label>Full name<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} required/></label><label>Phone number<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required/></label><label>Email address<input value={user.email} readOnly/></label><button className="primary-btn wide">Save Profile ✦</button>{status&&<p className="form-status">{status}</p>}<p className="auth-switch"><a href="/">← Back to Just Edith</a></p></form></div></div>
}

const siteLogo = window.location.port === '5173' ? '/logo.png' : '/justedith-beauty-parlour/frontend/logo.png';
function SiteModal({title,onClose,children}){return <div className="site-modal-overlay" onClick={onClose} role="presentation"><div className="site-modal" onClick={e=>e.stopPropagation()} role="dialog" aria-modal="true" aria-label={title}><div className="site-modal-head"><h2>{title}</h2><button className="site-modal-close" onClick={onClose} aria-label="Close">×</button></div><div className="site-modal-body">{children}</div></div></div>}

function App() {
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [booking, setBooking] = useState({ service: '', date: '', time: '', notes: '', paid_amount: '', mpesa_receipt: '' });
  const [contact, setContact] = useState({ name: '', email: '', message: '' });
  const [bookingStatus, setBookingStatus] = useState('');
  const [contactStatus, setContactStatus] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [rating, setRating] = useState({ service: 'Knotless Braids', customer_name: '', rating: 5, review: '' });
  const [ratingStatus, setRatingStatus] = useState('');
  const [ratingSummary, setRatingSummary] = useState({ average_rating: null, total_reviews: 0 });
  const [serviceRatings, setServiceRatings] = useState({});  const [reviews, setReviews] = useState([]);
  const [chat, setChat] = useState({ bookingId: localStorage.getItem('justedith_booking_id') || '', token: localStorage.getItem('justedith_chat_token') || '', message: '', image: null });
  const [chatMessages, setChatMessages] = useState([]);
  const [storePhotos, setStorePhotos] = useState([]);
  const [storeSearch, setStoreSearch] = useState('');
  const [storeCategory, setStoreCategory] = useState('All');
  const [storePrice, setStorePrice] = useState('All');
  const [storeSort, setStoreSort] = useState('Newest');
  const [storeSettings, setStoreSettings] = useState({sale_header_title:'Braids and Wigs on Sale',sale_header_subtitle:'Style your look today'});
  const [cart, setCart] = useState(() => { try { return JSON.parse(localStorage.getItem('justedith_cart') || '[]'); } catch { return []; } });
  const [cartOpen, setCartOpen] = useState(false);
  const [mpesaReceipt, setMpesaReceipt] = useState('');
  const [checkoutStatus, setCheckoutStatus] = useState('');
  const [walletBalance, setWalletBalance] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [chatStatus, setChatStatus] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [faqs,setFaqs]=useState([]);
  const [serviceList,setServiceList]=useState(services);
  const [homeBackground,setHomeBackground]=useState('');
  const [activeModal,setActiveModal]=useState(null);
  const [servicePreview,setServicePreview]=useState(null);

  const resetPrivateChat = () => {
    localStorage.removeItem('justedith_booking_id');
    localStorage.removeItem('justedith_chat_token');
    setChat({ bookingId: '', token: '', message: '', image: null });
    setChatMessages([]);
  };
  const requestFaqs = async () => { try { const r=await fetch((import.meta.env.VITE_API_BASE || (window.location.port==='5173'?'/api':'/justedith-beauty-parlour/backend/api'))+'/faqs.php'); const d=await r.json(); setFaqs(d.faqs||[]); } catch{} };


  useEffect(() => {
    getServices().then(r => setServiceList(r.services || services)).catch(() => setServiceList(services));
    getStorePhotos().then(result => setHomeBackground(result.settings?.home_background || '')).catch(() => {});
    getCurrentUser().then(result => {
      if (result.authenticated) setUser(result.user);
    }).catch(() => {}).finally(() => setAuthChecked(true));
  }, []);
  useEffect(() => {
    if (!user) { setNotifications([]); setWalletBalance(0); return; }
    getNotifications().then(r => setNotifications(r.notifications || [])).catch(() => {});
    getWallet().then(r => setWalletBalance(Number(r.balance || 0))).catch(() => {});
  }, [user]);
  useEffect(() => {
    if (!user) return;
    let stopped=false; let inFlight=false;
    const poll=async()=>{ if(stopped||inFlight) return; inFlight=true; try{const r=await getNotifications(); if(!stopped)setNotifications(r.notifications||[]);}catch{} finally{inFlight=false;} };
    const timer=setInterval(poll,30000);
    return ()=>{stopped=true;clearInterval(timer);};
  }, [user]);

  useEffect(() => { localStorage.setItem('justedith_cart', JSON.stringify(cart)); }, [cart]);

  const addToCart = (photo) => {
    if (!user) { window.location.href='/login'; return; }
    setCart(current => { const found=current.find(x=>x.id===photo.id); return found ? current.map(x=>x.id===photo.id?{...x,quantity:Math.min(99,x.quantity+1)}:x) : [...current,{id:photo.id,title:photo.title,category:photo.category,sale_price:Number(photo.sale_price||photo.original_price||0),image_url:photo.image_url,quantity:1}]; });
    setCartOpen(true);
  };
  const cartTotal = cart.reduce((sum,x)=>sum+Number(x.sale_price||0)*Number(x.quantity||1),0);
  const cartCount = cart.reduce((sum,x)=>sum+Number(x.quantity||1),0);
  const submitCheckout = async () => {
    setCheckoutStatus('Processing checkout…');
    try { const r=await checkoutStore({items:cart,payment_method:'mpesa',mpesa_receipt:mpesaReceipt}); setCheckoutStatus(`Order #${r.order_id} placed successfully.`); setCart([]); setMpesaReceipt(''); getNotifications().then(x=>setNotifications(x.notifications||[])); } catch(e) { setCheckoutStatus(e.message); }
  };
  const unreadNotifications = notifications.filter(n=>!Number(n.is_read)).length;

  const updateBooking = (e) => setBooking({ ...booking, [e.target.name]: e.target.value });
  const updateContact = (e) => setContact({ ...contact, [e.target.name]: e.target.value });

  async function handleBooking(e) {
    e.preventDefault();
    if (!user) {
      window.location.href = '/login';
      return;
    }
    const priceMap = {
      'Knotless Braids': 600, 'Boho Knotless': 600, 'Boho Twists': 1000, 'Coco Twists': 800,
      'Classic': 400, 'Hybrid': 700, 'Volume': 1000, 'Lash Removal': 100
    };
    const deposit = (priceMap[booking.service] || 0) / 2;
    if (Number(booking.paid_amount) !== deposit) {
      setBookingStatus(`Please pay exactly KSh ${deposit.toFixed(2)} (50%) to M-Pesa ${'254756617868'} and enter that amount below.`);
      return;
    }
    setBookingStatus('Checking your payment details and sending your booking…');
    try {
      const result = await submitBooking(booking);
      localStorage.setItem('justedith_booking_id', result.booking_id);
      localStorage.setItem('justedith_chat_token', result.chat_token);
      setChat({ bookingId: String(result.booking_id), token: result.chat_token, message: '', image: null });
      setBookingStatus(`✨ Booking #${result.booking_id} received. Deposit recorded as pending verification. Your private chat is ready.`);
      setBooking({ service: '', date: '', time: '', notes: '', paid_amount: '', mpesa_receipt: '' });
    } catch (error) {
      setBookingStatus(`Could not submit: ${error.message}`);
    }
  }

  async function loadRatings(service = rating.service) {
    try {
      const result = await getRatings(service);
      setRatingSummary(result.summary || { average_rating: null, total_reviews: 0 });
      setReviews(result.reviews || []);
    } catch (error) {
      setRatingStatus(error.message);
    }
  }

  async function handleRating(e) {
    e.preventDefault();
    setRatingStatus('Posting your review…');
    try {
      await submitRating({...rating, customer_name:user?.full_name||''});
      setRatingStatus('✨ Thank you! Your rating has been added.');
      setRating({ ...rating, customer_name: user?.full_name || '', review: '', rating: 5 });
      await loadRatings(rating.service);
      const all = await getRatings('');
      const map = {};
      (all.summaries || []).forEach(item => {
        map[item.service] = { average_rating: Number(item.average_rating) || 0, total_reviews: Number(item.total_reviews) || 0 };
      });
      setServiceRatings(map);
    } catch (error) {
      setRatingStatus(`Could not submit rating: ${error.message}`);
    }
  }

  async function loadChat() {
    if (!chat.bookingId || !chat.token) {
      setChatStatus('Enter the booking number and private chat token from your booking confirmation.');
      return;
    }
    setChatLoading(true);
    try {
      const result = await getChat(chat.bookingId, chat.token);
      setChatMessages(result.messages || []);
      setChatStatus('');
    } catch (error) {
      setChatStatus(error.message);
    } finally {
      setChatLoading(false);
    }
  }

  async function handleChat(e) {
    e.preventDefault();
    if (!chat.message.trim() && !chat.image) {
      setChatStatus('Write a message or attach a style reference photo.');
      return;
    }
    setChatStatus('Sending securely…');
    try {
      const form = new FormData();
      form.append('booking_id', chat.bookingId);
      form.append('token', chat.token);
      form.append('message', chat.message);
      if (chat.image) form.append('image', chat.image);
      await sendChatMessage(form);
      setChat({ ...chat, message: '', image: null });
      document.getElementById('chat-image-input').value = '';
      await loadChat();
      setChatStatus('Message sent to the service provider.');
    } catch (error) {
      setChatStatus(`Could not send: ${error.message}`);
    }
  }

  async function handleContact(e) {
    e.preventDefault();
    setContactStatus('Sending…');
    try {
      await submitContact(contact);
      setContactStatus('Message sent — thank you, lovely!');
      setContact({ name: '', email: '', message: '' });
    } catch (error) {
      setContactStatus(`Could not send: ${error.message}`);
    }
  }

  useEffect(() => {
    loadRatings();
    getRatings('').then(result => {
      const map = {};
      (result.summaries || []).forEach(item => {
        map[item.service] = { average_rating: Number(item.average_rating) || 0, total_reviews: Number(item.total_reviews) || 0 };
      });
      setServiceRatings(map);
    }).catch(() => {});
    requestFaqs();
    getStorePhotos().then(result => { setStorePhotos(result.photos || []); setStoreSettings(result.settings || {sale_header_title:'Braids and Wigs on Sale',sale_header_subtitle:'Style your look today'}); }).catch(() => setStorePhotos([]));
    const onScroll = () => setShowBackToTop(window.scrollY > 550);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const breadcrumbs = () => <div className="breadcrumbs"><a href="#home" onClick={e=>{e.preventDefault();scrollTo('home')}}>Home</a><span>›</span><span>{location.hash?location.hash.replace('#','').replaceAll('-',' '):'Home'}</span></div>;

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  if (!authChecked) return <div className="auth-loading">Loading Just Edith…</div>;
  if (window.location.pathname === '/login') return <LoginPage onSuccess={() => { resetPrivateChat(); window.location.href = '/'; }} />;
  if (window.location.pathname === '/register') return <RegisterPage onSuccess={() => { resetPrivateChat(); window.location.href = '/'; }} />;
  if (window.location.pathname === '/account') return <ProfilePage user={user} onUser={setUser} />;

  return (
    <div className="site-shell">
      <div className="top-strip">CUSTOMER-FRIENDLY PRICES <span>•</span> QUALITY SERVICE <span>•</span> ALWAYS SLAYED.</div>

      <header className="navbar">
        <button className="brand" onClick={() => scrollTo('home')} aria-label="Home">
          <img src="/logo.png" alt="Just Edith Beauty Parlour logo" />
        </button>

        <div className="nav-user">
          {user ? <><div className="user-avatar">{user.profile_image ? <img src={mediaUrl(user.profile_image)} alt={user.full_name} onError={e=>{e.currentTarget.style.display='none';e.currentTarget.nextSibling.style.display='grid'}} /> : null}<span style={{display:user.profile_image?'none':'grid'}}>{user.full_name?.charAt(0)}</span></div><span className="user-name">{user.full_name}</span><button className="icon-action" onClick={()=>setNotificationsOpen(!notificationsOpen)} aria-label="Notifications"><Icon name="bell"/>{unreadNotifications>0&&<b>{unreadNotifications}</b>}</button><button className="icon-action whatsapp-icon" onClick={()=>window.open('https://wa.me/254756617868','_blank')} aria-label="WhatsApp"><Icon name="whatsapp"/></button><button className="cart-icon" onClick={()=>setCartOpen(true)} aria-label="Cart"><Icon name="cart"/>{cartCount>0&&<b>{cartCount}</b>}</button><a href="/account" className="register-link">Profile</a><button className="logout-btn" onClick={async () => { await logoutUser(); resetPrivateChat(); setUser(null); }}>Logout</button></> : <><a href="/login">Login</a><a href="/register" className="register-link">Register</a></>}
        </div>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          ☰
        </button>

        <nav className={menuOpen ? 'nav-links open' : 'nav-links'}>
          <button onClick={() => scrollTo('home')}>Home</button>
          <button onClick={() => scrollTo('services')}>Services</button>
          <button onClick={() => scrollTo('rates')}>Rate Card</button>
          <button onClick={() => setActiveModal('reviews')}>Reviews</button>
          <button onClick={() => setActiveModal('private-chat')}>Private Chat</button>
          <button onClick={() => setActiveModal('store')}>Store</button>
          <button onClick={() => scrollTo('about')}>About</button><button onClick={() => setActiveModal('faq')}>FAQ</button><button onClick={() => setActiveModal('contact')}>Contact</button>
          <button className="nav-cta" onClick={() => setActiveModal('booking')}>Book an Appointment</button>
        </nav>
      </header>
      {user && notificationsOpen && <SiteModal title="Notifications" onClose={()=>setNotificationsOpen(false)}><div className="notifications-modal"><div className="notifications-head"><b>Your notifications</b><button onClick={()=>markAllNotificationsRead().then(()=>setNotifications(n=>n.map(x=>({...x,is_read:1}))))}>Mark all read</button></div>{notifications.length===0?<p className="muted">No notifications yet.</p>:notifications.map(n=><button key={n.id} className={!Number(n.is_read)?'notification-item unread':'notification-item'} onClick={()=>{markNotificationRead(n.id).catch(()=>{});setNotifications(ns=>ns.map(x=>x.id===n.id?{...x,is_read:1}:x));}}><span>{n.type==='order'?'🛍️':n.type==='booking'?'📅':'✦'}</span><div><b>{n.title}</b><p>{n.message}</p><small>{new Date(n.created_at).toLocaleString()}</small></div></button>)}</div></SiteModal>}

      <main>
        <section id="home" className="hero" style={homeBackground?{backgroundImage:`linear-gradient(rgba(20,12,18,.55),rgba(20,12,18,.55)),url("${mediaUrl(homeBackground)}")`}:undefined}>
          <div className="hero-copy">
            <p className="eyebrow">WELCOME TO JUST EDITH</p>
            <h1>Where every look gets <em>the touch of luxe.</em></h1>
            <p className="hero-text">
              Beauty made personal. Step into a space where protective styles,
              beautiful lashes and polished finishing touches come together to
              make you feel like your best self.
            </p>
            <div className="hero-actions">
              <button className="primary-btn" onClick={() => setActiveModal('booking')}>Book Your Glow-Up</button>
              <button className="ghost-btn" onClick={() => scrollTo('rates')}>View Rate Card</button>
            </div>
            <div className="hero-points">
              <span>✦ Quality service</span>
              <span>✦ Friendly prices</span>
              <span>✦ Always slayed</span>
            </div>
          </div>
          <div className="hero-art">
            <div className="art-orbit"></div>
            <div className="art-card">
              <span className="spark">✦</span>
              <span>YOUR BEAUTY.<br/><strong>YOUR MOMENT.</strong></span>
              <small>JUST EDITH BEAUTY PARLOUR</small>
            </div>
            <div className="floating-price">From<br/><b>KSh 600</b><br/><small>selected styles</small></div>
          </div>
        </section>

        <section className="intro-band">
          <div><span>01</span><h2>Luxury looks.</h2><p>Designed around you.</p></div>
          <div><span>02</span><h2>Skilled hands.</h2><p>Beautifully finished.</p></div>
          <div><span>03</span><h2>Happy prices.</h2><p>More glam, less stress.</p></div>
        </section>

        <section id="services" className="section">
          <div className="section-heading">
            <p className="eyebrow">OUR SIGNATURE SERVICES</p>
            <h2>Beauty that makes <em>an entrance.</em></h2>
            <p>From protective styles to statement lashes, choose your next signature look.</p>
          </div>
          <div className="service-grid">
            {serviceList.map((service, index) => (
              <article className="service-card" key={service.name}>
                <div className="service-number">0{index + 1}</div>
                {service.image_url ? <button type="button" className="service-image-button" onClick={()=>setServicePreview(service)}><img className="service-image" src={mediaUrl(service.image_url)} alt={service.name}/><span>⌕</span></button> : <div className="service-icon">{service.category === 'Lashes' ? '✦' : '◌'}</div>}
                <p className="service-category">{service.category}</p>
                <h3>{service.name}</h3>
                <p>{service.note || service.description}</p>
                <div className="service-card-rating">
                  {serviceRatings[service.name]?.total_reviews ? (
                    <>
                      <span className="stars">{'★'.repeat(Math.round(serviceRatings[service.name].average_rating))}{'☆'.repeat(5 - Math.round(serviceRatings[service.name].average_rating))}</span>
                      <b>{serviceRatings[service.name].average_rating.toFixed(1)}</b>
                      <small>({serviceRatings[service.name].total_reviews} review{serviceRatings[service.name].total_reviews === 1 ? '' : 's'})</small>
                    </>
                  ) : <small>No ratings yet</small>}
                </div>
                <div className="service-bottom">
                  <strong>{service.price}</strong>
                  <button onClick={() => {
                    setBooking({ ...booking, service: service.name });
                    setRating({ ...rating, service: service.name });
                    loadRatings(service.name);
                    setActiveModal('booking');
                  }}>Book →</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        {servicePreview && <SiteModal title={servicePreview.name} onClose={()=>setServicePreview(null)}><div className="service-preview-modal"><img src={mediaUrl(servicePreview.image_url)} alt={servicePreview.name}/><h3>{servicePreview.name}</h3><p>{servicePreview.note || servicePreview.description}</p><strong>{servicePreview.price || servicePreview.price_label}</strong></div></SiteModal>}

        {activeModal==='reviews' && <SiteModal title="Reviews & Ratings" onClose={()=>setActiveModal(null)}><section id="ratings" className="ratings-section section modal-section">
          <div className="section-heading">
            <p className="eyebrow">REAL CUSTOMER LOVE</p>
            <h2>Rate your <em>signature service.</em></h2>
            <p>Choose a service and tell future Just Edith clients how your experience felt.</p>
          </div>
          <div className="ratings-layout">
            <form className="rating-form" onSubmit={handleRating}>
              <label>Service<select value={rating.service} onChange={e => { setRating({ ...rating, service: e.target.value }); loadRatings(e.target.value); }} required>{services.map(s => <option key={s.name}>{s.name}</option>)}</select></label>
              <label>Your name<input value={user?.full_name || ''} readOnly placeholder="Log in to rate" required /></label>
              <label>Your rating<div className="star-picker">{[1,2,3,4,5].map(star => <button type="button" className={star <= rating.rating ? 'star selected' : 'star'} key={star} onClick={() => setRating({ ...rating, rating: star })}>★</button>)}</div></label>
              <label>Review<textarea value={rating.review} onChange={e => setRating({ ...rating, review: e.target.value })} placeholder="Tell us what you loved…" rows="4"></textarea></label>
              <button className="primary-btn" type="submit">Post Rating ✦</button>
              {ratingStatus && <p className="form-status">{ratingStatus}</p>}
            </form>
            <div className="reviews-panel">
              <div className="rating-summary"><strong>{ratingSummary.average_rating || '—'}</strong><div><div className="stars">★★★★★</div><span>{ratingSummary.total_reviews} review(s) for {rating.service}</span></div></div>
              {reviews.length === 0 ? <p className="muted">No reviews yet for this service. Be the first.</p> : reviews.map((review, i) => <article className="review-card" key={`${review.created_at}-${i}`}><div><b>{review.customer_name}</b><span className="stars">{'★'.repeat(Number(review.rating))}{'☆'.repeat(5 - Number(review.rating))}</span></div>{review.review && <p>{review.review}</p>}<small>{new Date(review.created_at).toLocaleDateString()}</small></article>)}
            </div>
          </div>
        </section></SiteModal>}

        <section id="rates" className="rates-section">
          <div className="rate-visual">
            <div className="monogram">JE</div>
            <p>NON STUDENT<br/><b>RATE CARD</b></p>
            <span>Every detail. Every finish. Every time.</span>
          </div>
          <div className="rate-content">
            <p className="eyebrow">PRICING WITH PERSONALITY</p>
            <h2>Non Student <em>Rate Card</em></h2>
            <div className="rate-columns">
              <div>
                <h3>Braids & Twists</h3>
                {services.filter(s => s.category === 'Braids & Twists').map(s => (
                  <div className="rate-row" key={s.name}><span>{s.name}</span><b>{s.price}</b></div>
                ))}
              </div>
              <div>
                <h3>Lashes</h3>
                {services.filter(s => s.category === 'Lashes').map(s => (
                  <div className="rate-row" key={s.name}><span>{s.name}</span><b>{s.price}</b></div>
                ))}
              </div>
            </div>
            <div className="extras">
              <h3>Extras</h3>
              <div className="extra-grid">
                {extras.map(([name, price]) => <div key={name}><span>{name}</span><b>{price}</b></div>)}
              </div>
            </div>
            <p className="rate-note">* “From” prices may vary depending on length, density and customisation.</p>
          </div>
        </section>

        {activeModal==='store' && <SiteModal title="Just Edith Store" onClose={()=>setActiveModal(null)}><section id="store" className="store-section section modal-section">
          <div className="sale-header">
            <div><p className="eyebrow">JUST EDITH STORE</p><h2>{storeSettings.sale_header_title}</h2><p>{storeSettings.sale_header_subtitle}</p></div>
            <button className="primary-btn" onClick={()=>setCartOpen(true)}>View Cart {cartCount>0&&`(${cartCount})`}</button>
          </div>
          <div className="user-store-filters">
            <div className="store-search-wrap"><span>⌕</span><input value={storeSearch} onChange={e=>setStoreSearch(e.target.value)} placeholder="Search braids, wigs and styles..." aria-label="Search products"/>{storeSearch&&<button type="button" onClick={()=>setStoreSearch('')} aria-label="Clear search">×</button>}</div>
            <select value={storeCategory} onChange={e=>setStoreCategory(e.target.value)}><option>All</option><option>Braids</option><option>Wigs</option></select>
            <select value={storePrice} onChange={e=>setStorePrice(e.target.value)}><option value="All">All prices</option><option value="Under 1000">Under KSh 1,000</option><option value="1000-3000">KSh 1,000–3,000</option><option value="Above 3000">Above KSh 3,000</option></select>
            <select value={storeSort} onChange={e=>setStoreSort(e.target.value)}><option>Newest</option><option>Price low-high</option><option>Price high-low</option><option>Name A-Z</option></select>
            <button className="store-filter-reset" type="button" onClick={()=>{setStoreSearch('');setStoreCategory('All');setStorePrice('All');setStoreSort('Newest')}}>Reset</button>
          </div>
          {(()=>{let list=storePhotos.filter(photo=>{const q=storeSearch.toLowerCase();const matches=!q||`${photo.title||''} ${photo.category||''}`.toLowerCase().includes(q);const cat=storeCategory==='All'||photo.category===storeCategory;const value=Number(photo.sale_price||photo.original_price||0);const pr=storePrice==='All'||(storePrice==='Under 1000'&&value<1000)||(storePrice==='1000-3000'&&value>=1000&&value<=3000)||(storePrice==='Above 3000'&&value>3000);return matches&&cat&&pr});if(storeSort==='Price low-high')list.sort((a,b)=>Number(a.sale_price||a.original_price||0)-Number(b.sale_price||b.original_price||0));if(storeSort==='Price high-low')list.sort((a,b)=>Number(b.sale_price||b.original_price||0)-Number(a.sale_price||a.original_price||0));if(storeSort==='Name A-Z')list.sort((a,b)=>(a.title||'').localeCompare(b.title||''));return list;})().length === 0 ? (
            <div className="store-empty"><span>✦</span><h3>{storePhotos.length===0?'New styles are coming soon.':'No products found.'}</h3><p>{storePhotos.length===0?'Check back here for the latest braids and wigs available from Just Edith.':'Try changing your search or filters.'}</p></div>
          ) : (
            <div className="store-grid">
              {(()=>{let list=storePhotos.filter(photo=>{const q=storeSearch.toLowerCase();const matches=!q||`${photo.title||''} ${photo.category||''}`.toLowerCase().includes(q);const cat=storeCategory==='All'||photo.category===storeCategory;const value=Number(photo.sale_price||photo.original_price||0);const pr=storePrice==='All'||(storePrice==='Under 1000'&&value<1000)||(storePrice==='1000-3000'&&value>=1000&&value<=3000)||(storePrice==='Above 3000'&&value>3000);return matches&&cat&&pr});if(storeSort==='Price low-high')list.sort((a,b)=>Number(a.sale_price||a.original_price||0)-Number(b.sale_price||b.original_price||0));if(storeSort==='Price high-low')list.sort((a,b)=>Number(b.sale_price||b.original_price||0)-Number(a.sale_price||a.original_price||0));if(storeSort==='Name A-Z')list.sort((a,b)=>(a.title||'').localeCompare(b.title||''));return list;})().map(photo => { const price=Number(photo.sale_price||photo.original_price||0); return <article className="store-card" key={photo.id}>
                <div className="store-image-wrap"><img src={mediaUrl(photo.image_url)} alt={photo.title || 'Just Edith style'} loading="lazy" /></div>
                <div className="store-card-body"><span>{photo.category || 'Style'}</span><h3>{photo.title || 'Just Edith Style'}</h3><div className="store-price">{photo.original_price&&Number(photo.original_price)>price&&<del>KSh {Number(photo.original_price).toLocaleString()}</del>}<strong>KSh {price.toLocaleString()}</strong></div><button className="primary-btn add-cart" onClick={()=>addToCart(photo)}>Add to Cart</button></div>
              </article>})}
            </div>
          )}
        </section></SiteModal>}

        {activeModal==='private-chat' && <SiteModal title="Private Style Chat" onClose={()=>setActiveModal(null)}><section id="private-chat" className="private-chat-section section modal-section">
          <div className="section-heading">
            <p className="eyebrow">PRIVATE STYLE CHAT</p>
            <h2>Show us exactly what you <em>want to slay.</em></h2>
            <p>After booking, use your private booking number and chat token to message the service provider. You can attach a photo of the hairstyle you want to be plaited.</p>
          </div>
          <div className="chat-layout">
            <div className="chat-info">
              <div className="chat-lock">🔒</div>
              <h3>Your private appointment room</h3>
              <p>Your conversation is linked to your booking. Upload a reference photo, explain the length or colour you want, and receive a reply from the provider.</p>
              <div className="chat-security"><b>Photo uploads</b><span>JPG, PNG, WEBP or GIF · max 5MB</span></div>
            </div>
            <div className="customer-chat">
              <div className="chat-access">
                <label>Booking number<input value={chat.bookingId} onChange={e => setChat({ ...chat, bookingId: e.target.value })} placeholder="e.g. 12" /></label>
                <label>Private chat token<input value={chat.token} onChange={e => setChat({ ...chat, token: e.target.value })} placeholder="Token from booking confirmation" /></label>
                <button className="ghost-btn" type="button" onClick={loadChat}>Open Chat</button>
              </div>
              <div className="messages customer-messages">
                {chatMessages.length === 0 && <p className="muted">Your messages will appear here.</p>}
                {chatMessages.map(m => <div key={m.id} className={m.sender === 'customer' ? 'bubble customer-bubble' : 'bubble provider-bubble'}><small>{m.sender === 'customer' ? 'You' : 'Just Edith · Service Provider'}</small>{m.message && <p>{m.message}</p>}{m.image_path && <img src={mediaUrl(m.image_path)} alt="Your requested hairstyle reference"/>}<time>{new Date(m.created_at).toLocaleString()}</time></div>)}
              </div>
              <form className="chat-compose" onSubmit={handleChat}>
                <textarea value={chat.message} onChange={e => setChat({ ...chat, message: e.target.value })} placeholder="Tell your provider what you want…" rows="3"></textarea>
                <div className="chat-actions"><label className="upload-btn">📷 Attach style photo<input id="chat-image-input" type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={e => setChat({ ...chat, image: e.target.files?.[0] || null })} /></label><button className="primary-btn" type="submit">Send ✦</button></div>
                {chat.image && <p className="file-picked">Selected: {chat.image.name}</p>}
                {chatLoading && <p className="form-status">Loading conversation…</p>}
                {chatStatus && <p className="form-status">{chatStatus}</p>}
              </form>
            </div>
          </div>
        </section></SiteModal>}

        <section id="about" className="about-section section">
          <div className="about-copy">
            <p className="eyebrow">THE JUST EDITH EXPERIENCE</p>
            <h2>Come for the look.<br/><em>Leave with the confidence.</em></h2>
            <p>
              Just Edith Beauty Parlour is built for the girl who wants to feel
              polished without feeling pressured. We believe luxury can be warm,
              accessible and personal.
            </p>
            <p>
              Whether you're refreshing your protective style, getting lash-ready
              for an event or simply treating yourself, every appointment is a
              chance to slow down, glow up and leave feeling beautifully you.
            </p>
            <button className="primary-btn" onClick={() => setActiveModal('booking')}>Let's Get You Slayed</button>
          </div>
          <div className="about-card">
            <div className="quote-mark">“</div>
            <blockquote>Quality service. Customer-friendly prices. Always slayed.</blockquote>
            <div className="signature">Just Edith</div>
          </div>
        </section>

        {activeModal==='booking' && <SiteModal title="Book Your Beauty Moment" onClose={()=>setActiveModal(null)}><section className="booking-section modal-section">
          <div className="booking-wrap">
            <div className="booking-copy">
              <p className="eyebrow">READY WHEN YOU ARE</p>
              <h2>Book your <em>beauty moment.</em></h2>
              <p>Bookings require a 50% deposit. Pay the exact deposit shown below to M-Pesa <strong>+254 756 617868</strong>, then enter the M-Pesa transaction code so we can verify your payment.</p>
              <div className="booking-note"><span>✦</span><div><b>Appointment requests</b><small>We’ll confirm your selected date and time after reviewing availability.</small></div></div>
            </div>
            <form className="form-card" onSubmit={handleBooking}>
              {!user && <div className="login-required"><b>🔐 Login required</b><span>Please <a href="/login">log in</a> or <a href="/register">register</a> before booking.</span></div>}
              <div className="form-grid">
                <label>Customer<input value={user?.full_name || ''} readOnly placeholder="Log in to continue" /></label>
                <label>Phone number<input value={user?.phone || ''} readOnly placeholder="Your registered phone" /></label>
                <label>Service<select name="service" value={booking.service} onChange={updateBooking} required><option value="">Choose a service</option>{services.map(s => <option key={s.name} value={s.name}>{s.name} — {s.price}</option>)}</select></label>
                <label>Preferred date<input type="date" name="date" value={booking.date} onChange={updateBooking} required /></label>
                <label>Preferred time<input type="time" name="time" value={booking.time} onChange={updateBooking} required /></label>
              </div>
              <label>Notes / special requests<textarea name="notes" value={booking.notes} onChange={updateBooking} placeholder="Tell us about your preferred length, colour, event, etc." rows="4"></textarea></label>
              <div className="payment-box">
                <div><span>BOOKING DEPOSIT</span><strong>50% upfront</strong></div>
                <p>Send the deposit to <b>+254 756 617868</b> via M-Pesa before submitting.</p>
                {booking.service && <small>Required deposit for <b>{booking.service}</b>: <strong>KSh {{'Knotless Braids':600,'Boho Knotless':600,'Boho Twists':1000,'Coco Twists':800,'Classic':400,'Hybrid':700,'Volume':1000,'Lash Removal':100}[booking.service]/2}</strong></small>}
                <label>Amount paid (KSh)<input type="number" name="paid_amount" min="0" step="0.01" value={booking.paid_amount} onChange={updateBooking} required placeholder="Enter the 50% deposit" /></label>
                <label>M-Pesa transaction code<input name="mpesa_receipt" value={booking.mpesa_receipt} onChange={updateBooking} required placeholder="e.g. QAB12CD34E" /></label>
              </div>
              <button className="primary-btn wide" type="submit" disabled={!user}>Request Appointment ✦</button>
              {bookingStatus && <p className="form-status">{bookingStatus}</p>}
            </form>
          </div>
        </section></SiteModal>}

        {activeModal==='faq' && <SiteModal title="Frequently Asked Questions" onClose={()=>setActiveModal(null)}><section className="faq-section modal-section"><div className="section-heading"><p className="eyebrow">HELP & ANSWERS</p><h2>Frequently asked <em>questions.</em></h2></div><div className="faq-list">{faqs.length?faqs.map(f=><details key={f.id} className="faq-card"><summary>{f.question}</summary>{f.asked_by&&<div className="faq-asked-by"><span>Asked by</span> <strong>{f.asked_by}</strong></div>}{f.answer&&<div className="faq-admin-reply"><span>Reply by admin</span><p>{f.answer}</p></div>}</details>):<p className="muted">No FAQs have been added yet.</p>}</div></section></SiteModal>}

        {activeModal==='contact' && <SiteModal title="Contact Just Edith" onClose={()=>setActiveModal(null)}><section className="contact-section modal-section">
          <div className="contact-details">
            <p className="eyebrow">LET'S TALK BEAUTY</p>
            <h2>Have a question? <em>We're listening.</em></h2>
            <p>Use the form or contact the parlour directly. Replace the sample contact details below with your real salon details.</p>
            <div className="contact-item"><span>✦</span><div><b>Phone / WhatsApp</b><p>+254 7XX XXX XXX</p></div></div>
            <div className="contact-item"><span>✦</span><div><b>Location</b><p>Your salon location, Kenya</p></div></div>
            <div className="contact-item"><span>✦</span><div><b>Hours</b><p>Mon – Sat · 9:00 AM – 7:00 PM</p></div></div>
          </div>
          <form className="contact-form" onSubmit={handleContact}>
            <label>Name<input name="name" value={contact.name} onChange={updateContact} required placeholder="Your name" /></label>
            <label>Email<input type="email" name="email" value={contact.email} onChange={updateContact} required placeholder="you@example.com" /></label>
            <label>Message<textarea name="message" value={contact.message} onChange={updateContact} required placeholder="How can we help?" rows="6"></textarea></label>
            <button className="primary-btn" type="submit">Send Message</button>
            {contactStatus && <p className="form-status">{contactStatus}</p>}
          </form>
        </section></SiteModal>}

      </main>

      {cartOpen && <div className="cart-overlay" onClick={()=>setCartOpen(false)}><aside className="cart-drawer" onClick={e=>e.stopPropagation()}><div className="cart-head"><div><span className="eyebrow">JUST EDITH STORE</span><h2>Your Cart <span className="cart-count-label">{cartCount} item{cartCount===1?'':'s'}</span></h2></div><button className="cart-close" onClick={()=>setCartOpen(false)} aria-label="Close cart">×</button></div>{cart.length===0?<div className="store-empty"><div className="empty-cart-icon"><Icon name="cart" size={34}/></div><h3>Your cart is empty.</h3><p>Add a braid or wig from the sale section.</p></div>:<><div className="cart-items">{cart.map(item=><div className="cart-item" key={item.id}><div className="cart-thumb"><img src={mediaUrl(item.image_url)} alt=""/><span>{item.category}</span></div><div className="cart-item-main"><b>{item.title}</b><small>KSh {Number(item.sale_price).toLocaleString()} each</small><div className="cart-item-bottom"><div className="qty"><button aria-label="Decrease quantity" onClick={()=>setCart(c=>c.map(x=>x.id===item.id?{...x,quantity:Math.max(1,x.quantity-1)}:x))}><Icon name="minus" size={14}/></button><span>{item.quantity}</span><button aria-label="Increase quantity" onClick={()=>setCart(c=>c.map(x=>x.id===item.id?{...x,quantity:Math.min(99,x.quantity+1)}:x))}><Icon name="plus" size={14}/></button></div><strong>KSh {(Number(item.sale_price)*Number(item.quantity||1)).toLocaleString()}</strong><button className="remove" aria-label={`Remove ${item.title}`} onClick={()=>setCart(c=>c.filter(x=>x.id!==item.id))}><Icon name="trash" size={15}/><span>Remove</span></button></div></div></div>)}</div><div className="cart-total"><span>Order total</span><strong>KSh {cartTotal.toLocaleString()}</strong></div><div className="checkout-box"><div className="checkout-title"><span className="eyebrow">SECURE CHECKOUT</span><h3>Pay with M-Pesa</h3><p>Send the exact order total to <b>+254 756 617868</b>, then enter your M-Pesa transaction code below.</p></div><div className="payment-option active"><span className="payment-icon mpesa">M</span><span><b>M-Pesa</b><small>Manual verification</small></span></div><input className="payment-ref" placeholder="M-Pesa transaction code" value={mpesaReceipt} onChange={e=>setMpesaReceipt(e.target.value)}/><button className="primary-btn wide checkout-btn" onClick={submitCheckout} disabled={!mpesaReceipt.trim()}><Icon name="cart" size={17}/> Pay KSh {cartTotal.toLocaleString()} & Checkout</button>{checkoutStatus&&<p className="form-status">{checkoutStatus}</p>}<small className="checkout-note">Your order will remain pending until the M-Pesa payment is verified by the admin.</small></div></>}</aside></div>}

      {showBackToTop && <button className="back-to-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top">↑ <span>Back to top</span></button>}

      <footer>
        <div className="footer-main">
          <img src={siteLogo} alt="Just Edith Beauty Parlour" />
          <p>Where every look gets <em>the touch of luxe.</em></p>
          <div className="footer-actions">
            <a className="whatsapp-btn" href="https://wa.me/254756617868" target="_blank" rel="noreferrer">Chat on WhatsApp →</a>
            <button onClick={() => setActiveModal('booking')}>Book an appointment →</button>
          </div>
        </div>
        <div className="footer-socials" aria-label="Social media">
          <span>Follow us</span>
          <a href="https://twitter.com/" target="_blank" rel="noreferrer" aria-label="Twitter" title="Twitter">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.77 7.74L23.2 22h-6.24l-4.89-6.39L6.49 22H3.37l7.24-8.28L2.8 2h6.4l4.42 5.84L18.9 2Zm-1.1 17.9h1.73L8.27 3.98H6.41L17.8 19.9Z"/></svg>
          </a>
          <a href="https://instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram" title="Instagram">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.4" cy="6.7" r="1" className="icon-fill"/></svg>
          </a>
          <a href="https://facebook.com/" target="_blank" rel="noreferrer" aria-label="Facebook" title="Facebook">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 8h3V4h-3c-3.31 0-5 1.79-5 5v3H6v4h3v4h4v-4h3l1-4h-4V9c0-.67.33-1 1-1Z"/></svg>
          </a>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Just Edith Beauty Parlour</span>
          <span>CUSTOMER-FRIENDLY PRICES · QUALITY SERVICE · ALWAYS SLAYED.</span>
        </div>
      </footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(window.location.pathname === '/provider' ? <ProviderApp /> : window.location.pathname.startsWith('/admin') ? <Admin /> : <App />);
