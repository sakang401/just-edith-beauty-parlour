<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
require_once __DIR__ . '/notify.php';
requireAdmin();

function financeBody(){ return json_decode(file_get_contents('php://input'), true) ?: []; }
function financeResponse($data,$code=200){ http_response_code($code); echo json_encode($data); exit; }

if($_SERVER['REQUEST_METHOD']==='GET'){
  $from=$_GET['from'] ?? date('Y-m-01');
  $to=$_GET['to'] ?? date('Y-m-d');
  $params=[$from,$to];
  $sales=$pdo->prepare("SELECT COALESCE(SUM(total_amount),0) revenue, COUNT(*) order_count FROM orders WHERE payment_status='paid' AND DATE(created_at) BETWEEN ? AND ?");
  $sales->execute($params); $s=$sales->fetch() ?: [];
  $costs=$pdo->prepare("SELECT COALESCE(SUM(oi.unit_cost*oi.quantity),0) product_cost FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.payment_status='paid' AND DATE(o.created_at) BETWEEN ? AND ?");
  $costs->execute($params); $c=$costs->fetch() ?: [];
  $bookings=$pdo->prepare("SELECT COALESCE(SUM(deposit_amount),0) revenue, COUNT(*) booking_count FROM bookings WHERE payment_status='verified' AND DATE(created_at) BETWEEN ? AND ?");
  $bookings->execute($params); $b=$bookings->fetch() ?: [];
  $manual=$pdo->prepare("SELECT COALESCE(SUM(total_sale),0) revenue, COALESCE(SUM(total_cost),0) product_cost, COALESCE(SUM(quantity),0) units FROM inventory_sales WHERE DATE(sold_at) BETWEEN ? AND ?");
  $manual->execute($params); $m=$manual->fetch() ?: [];
  $exp=$pdo->prepare("SELECT COALESCE(SUM(amount),0) expenses FROM business_expenses WHERE expense_date BETWEEN ? AND ?"); $exp->execute($params); $e=$exp->fetch() ?: [];
  $revenue=(float)$s['revenue']+(float)$m['revenue']+(float)$b['revenue']; $cogs=(float)$c['product_cost']+(float)$m['product_cost']; $expenses=(float)$e['expenses'];
  $products=$pdo->query("SELECT * FROM inventory_products WHERE active=1 ORDER BY category,name")->fetchAll();
  $styles=$pdo->query("SELECT id,title,category,sale_price,buying_price,original_price,is_on_sale FROM style_photos ORDER BY category,title")->fetchAll();
  $expensesRows=$pdo->prepare("SELECT * FROM business_expenses WHERE expense_date BETWEEN ? AND ? ORDER BY expense_date DESC,id DESC"); $expensesRows->execute($params);
  $salesRows=$pdo->prepare("SELECT s.*,p.name,p.category FROM inventory_sales s JOIN inventory_products p ON p.id=s.product_id WHERE DATE(s.sold_at) BETWEEN ? AND ? ORDER BY s.sold_at DESC,s.id DESC"); $salesRows->execute($params);
  $orders=$pdo->prepare("SELECT o.id,o.total_amount,o.payment_method,o.payment_status,o.status,o.created_at,u.full_name FROM orders o JOIN users u ON u.id=o.user_id WHERE DATE(o.created_at) BETWEEN ? AND ? ORDER BY o.created_at DESC LIMIT 100"); $orders->execute($params);
  financeResponse(['success'=>true,'period'=>['from'=>$from,'to'=>$to],'summary'=>[
    'revenue'=>$revenue,'cogs'=>$cogs,'gross_profit'=>$revenue-$cogs,'expenses'=>$expenses,'net_profit'=>$revenue-$cogs-$expenses,
    'order_count'=>(int)$s['order_count'],'booking_count'=>(int)$b['booking_count'],'manual_units'=>(int)$m['units']
  ],'products'=>$products,'styles'=>$styles,'expenses'=>$expensesRows->fetchAll(),'manual_sales'=>$salesRows->fetchAll(),'orders'=>$orders->fetchAll()]);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $d=financeBody(); $action=$d['action']??'';
  if($action==='product'){
    $name=trim((string)($d['name']??'')); $category=$d['category']??'Other';
    if($name===''||!in_array($category,['Braids','Wigs','Oil','Other'],true)) financeResponse(['success'=>false,'message'=>'Product name and category are required.'],422);
    $s=$pdo->prepare("INSERT INTO inventory_products(name,category,buying_price,selling_price,stock_quantity) VALUES(?,?,?,?,?)");
    $s->execute([$name,(string)$category,(float)($d['buying_price']??0),(float)($d['selling_price']??0),(int)($d['stock_quantity']??0)]);
    financeResponse(['success'=>true,'id'=>$pdo->lastInsertId()]);
  }
  if($action==='sale'){
    $pid=(int)($d['product_id']??0); $qty=max(1,(int)($d['quantity']??0));
    $s=$pdo->prepare("SELECT * FROM inventory_products WHERE id=? AND active=1 FOR UPDATE"); $pdo->beginTransaction(); $s->execute([$pid]); $p=$s->fetch();
    if(!$p){$pdo->rollBack();financeResponse(['success'=>false,'message'=>'Product not found.'],422);}
    if((int)$p['stock_quantity']<$qty){$pdo->rollBack();financeResponse(['success'=>false,'message'=>'Not enough stock for this sale.'],422);}
    $sell=(float)($d['selling_price']??$p['selling_price']); $buy=(float)$p['buying_price']; $total=$sell*$qty; $cost=$buy*$qty;
    $x=$pdo->prepare("INSERT INTO inventory_sales(product_id,quantity,buying_price,selling_price,total_sale,total_cost,sold_at,notes) VALUES(?,?,?,?,?,?,?,?)");
    $x->execute([$pid,$qty,$buy,$sell,$total,$cost,!empty($d['sold_at'])?$d['sold_at']:date('Y-m-d H:i:s'),trim((string)($d['notes']??''))?:null]);
    $pdo->prepare("UPDATE inventory_products SET stock_quantity=stock_quantity-? WHERE id=?")->execute([$qty,$pid]); $pdo->commit();
    notifyAdmin($pdo,'Manual sale recorded',$p['name'].' sale of KSh '.number_format($total,2).' recorded.','finance');
    financeResponse(['success'=>true]);
  }
  if($action==='expense'){
    $category=$d['category']??'Other'; $desc=trim((string)($d['description']??'')); $amount=(float)($d['amount']??0); $date=$d['expense_date']??date('Y-m-d');
    if($desc===''||$amount<=0||!in_array($category,['Rent','Tools','Oil','Stock','Utilities','Transport','Other'],true)) financeResponse(['success'=>false,'message'=>'Enter a valid expense description, category and amount.'],422);
    $s=$pdo->prepare("INSERT INTO business_expenses(category,description,amount,expense_date) VALUES(?,?,?,?)"); $s->execute([$category,$desc,$amount,$date]); financeResponse(['success'=>true]);
  }
}
if($_SERVER['REQUEST_METHOD']==='PUT'){
  $d=financeBody();
  if(($d['action']??'')==='product'){
    $id=(int)($d['id']??0); if(!$id) financeResponse(['success'=>false,'message'=>'Product ID required.'],422);
    $s=$pdo->prepare("UPDATE inventory_products SET name=?,category=?,buying_price=?,selling_price=?,stock_quantity=?,active=? WHERE id=?");
    $s->execute([trim((string)$d['name']),$d['category'],(float)$d['buying_price'],(float)$d['selling_price'],(int)$d['stock_quantity'],!empty($d['active'])?1:0,$id]); financeResponse(['success'=>true]);
  }
}
if($_SERVER['REQUEST_METHOD']==='DELETE'){
  $d=financeBody(); $id=(int)($d['id']??0); if($id){$pdo->prepare('DELETE FROM business_expenses WHERE id=?')->execute([$id]); financeResponse(['success'=>true]);}
}
financeResponse(['success'=>false,'message'=>'Method not allowed.'],405);
?>
