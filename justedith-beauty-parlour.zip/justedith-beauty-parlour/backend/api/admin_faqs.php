<?php
require_once __DIR__ . '/admin_common.php';
$pdo->exec('CREATE TABLE IF NOT EXISTS faqs (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question VARCHAR(255) NOT NULL, answer TEXT NOT NULL, asked_by VARCHAR(150) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB');
try{$pdo->exec('ALTER TABLE faqs ADD COLUMN asked_by VARCHAR(150) NULL');}catch(Throwable $e){}
$m=$_SERVER['REQUEST_METHOD'];
if($m==='GET') adminResponse(['faqs'=>$pdo->query('SELECT * FROM faqs ORDER BY id DESC')->fetchAll()]);
$d=body();
if($m==='POST'){
 $pdo->prepare('INSERT INTO faqs(question,answer,asked_by) VALUES(?,?,?)')->execute([cleanString($d['question']??''),cleanString($d['answer']??''),cleanString($d['asked_by']??'')]); adminResponse(['success'=>true]);
}
if($m==='PUT'){ $pdo->prepare('UPDATE faqs SET question=?,answer=?,asked_by=? WHERE id=?')->execute([cleanString($d['question']??''),cleanString($d['answer']??''),cleanString($d['asked_by']??''),(int)($d['id']??0)]); adminResponse(['success'=>true]); }
if($m==='DELETE'){ $pdo->prepare('DELETE FROM faqs WHERE id=?')->execute([(int)($d['id']??0)]); adminResponse(['success'=>true]); }
adminResponse(['message'=>'Method not allowed'],405);
