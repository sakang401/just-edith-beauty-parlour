<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../config/admin.php'; requireAdmin();
function adminResponse($data,$code=200){http_response_code($code);echo json_encode($data);exit;}
try{$pdo->exec("ALTER TABLE service_ratings ADD COLUMN approved TINYINT(1) NOT NULL DEFAULT 0");}catch(Throwable $e){}
$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){ $rows=$pdo->query("SELECT id,service,customer_name,rating,review,created_at,approved FROM service_ratings ORDER BY created_at DESC")->fetchAll(); adminResponse(['success'=>true,'ratings'=>$rows]); }
$d=getJsonBody();
if($method==='PUT'){ $id=(int)($d['id']??0);$pdo->prepare('UPDATE service_ratings SET approved=? WHERE id=?')->execute([($d['status']??'')==='approved'?1:0,$id]);adminResponse(['success'=>true]); }
if($method==='DELETE'){ $pdo->prepare('DELETE FROM service_ratings WHERE id=?')->execute([(int)($d['id']??0)]);adminResponse(['success'=>true]); }
adminResponse(['success'=>false,'message'=>'Method not allowed'],405);
