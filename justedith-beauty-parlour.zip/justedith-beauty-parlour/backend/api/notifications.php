<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php';
session_start();
if($_SERVER['REQUEST_METHOD']==='GET'){
  if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'message'=>'Please log in.']);exit;}
  $s=$pdo->prepare("SELECT id,title,message,type,is_read,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50");$s->execute([$_SESSION['user_id']]);
  echo json_encode(['success'=>true,'notifications'=>$s->fetchAll()]);exit;
}
if($_SERVER['REQUEST_METHOD']==='PUT'){
  if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'message'=>'Please log in.']);exit;}
  $d=json_decode(file_get_contents('php://input'),true)?:[];
  if(!empty($d['all'])) $pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$_SESSION['user_id']]);
  elseif(isset($d['id'])) {$s=$pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?");$s->execute([(int)$d['id'],$_SESSION['user_id']]);}
  echo json_encode(['success'=>true]);exit;
}
http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);
