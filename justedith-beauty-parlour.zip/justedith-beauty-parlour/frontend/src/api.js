const API_BASE = import.meta.env.VITE_API_BASE || (window.location.port === '5173' ? '/api' : '/justedith-beauty-parlour/backend/api');

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}/${path}`, { credentials: 'include', ...options });
  } catch (networkError) {
    throw new Error('Cannot reach the PHP server. Start Apache in XAMPP and make sure the project is inside C:\\xampp\\htdocs\\justedith-beauty-parlour.');
  }
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json().catch(() => ({})) : {};
  if (!response.ok) throw new Error(data.message || `Server error (${response.status}). Check Apache/PHP.`);
  return data;
}
export const submitBooking = payload => request('bookings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
export const submitContact = payload => request('contact.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
export const submitRating = payload => request('ratings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
export const getRatings = service => request(`ratings.php?service=${encodeURIComponent(service)}`);
export const sendChatMessage = formData => request('chat.php',{method:'POST',body:formData});
export const getChat = (bookingId,token) => request(`chat.php?booking_id=${encodeURIComponent(bookingId)}&token=${encodeURIComponent(token)}`);
export const registerUser = formData => request('auth.php',{method:'POST',body:formData});
export const loginUser = formData => request('auth.php',{method:'POST',body:formData});
export const getCurrentUser = () => request('auth.php');
export const logoutUser = () => { const f=new FormData(); f.append('action','logout'); return request('auth.php',{method:'POST',body:f}); };
export const updateProfile = formData => request('auth.php',{method:'POST',body:formData});
export const getStorePhotos = () => request('store.php');
export const getNotifications = () => request('notifications.php',{signal:AbortSignal.timeout(8000)});
export const markNotificationRead = id => request('notifications.php',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
export const markAllNotificationsRead = () => request('notifications.php',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({all:true})});
export const getWallet = () => request('wallet.php');
export const checkoutStore = payload => request('shop_checkout.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});

// Convert backend-upload paths (e.g. /justedith-beauty-parlour/backend/uploads/...)
// into URLs that work from both Vite (localhost:5173) and Apache.
export const mediaUrl = (value) => {
  if (!value) return '';
  if (/^(https?:|data:|blob:)/i.test(value)) return value;
  let path = value.startsWith('/') ? value : `/${value}`;
  // Older records may contain an uploads path without the project prefix.
  if (path.startsWith('/uploads/')) path = `/justedith-beauty-parlour/backend${path}`;
  // During Vite development the PHP API is served by Apache on port 80.
  if (window.location.port === '5173') {
    return `${window.location.protocol}//${window.location.hostname}${path}`;
  }
  return path;
};

export const adminRequest = async (path, options={}) => {
  let response;
  const pin = sessionStorage.getItem('justedith_admin_pin') || '';
  try {
    response = await fetch(`${API_BASE}/${path}`, { credentials:'include', ...options,
      headers: options.body instanceof FormData ? {'X-Admin-Pin':pin,...(options.headers||{})} : {'Content-Type':'application/json','X-Admin-Pin':pin,...(options.headers||{})} });
  } catch { throw new Error('Cannot reach the PHP server. Start Apache in XAMPP.'); }
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.message || `Server error (${response.status})`);
  return data;
};

export async function getServices(){ return request('services.php'); }
