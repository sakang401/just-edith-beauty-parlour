<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
require_once __DIR__ . '/notify.php';
requireAdmin();
function adminResponse($data, $code=200) {
  http_response_code($code); echo json_encode($data); exit;
}
function body() { return getJsonBody(); }

$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){ $rows=$pdo->query("SELECT * FROM bookings ORDER BY appointment_date DESC,appointment_time DESC")->fetchAll(); adminResponse(['success'=>true,'bookings'=>$rows]);}
$d=body();
if($method==='PUT'){ $id=(int)($d['id']??0); $lookup=$pdo->prepare('SELECT user_id,service,appointment_date FROM bookings WHERE id=?'); $lookup->execute([$id]); $booking=$lookup->fetch(); if(!$booking){adminResponse(['success'=>false,'message'=>'Booking not found.'],404);} if($id<1){adminResponse(['success'=>false,'message'=>'A valid booking ID is required.'],422);} if(isset($d['status']) && in_array(cleanString($d['status']),['confirmed','completed'],true)){ $check=$pdo->prepare('SELECT payment_status FROM bookings WHERE id=?'); $check->execute([$id]); $payment=$check->fetchColumn(); if($payment!=='verified'){adminResponse(['success'=>false,'message'=>'Verify the M-Pesa payment before confirming the service.'],409);} } if(isset($d['payment_status'])){ $ps=cleanString($d['payment_status']); if(!in_array($ps,['pending_verification','verified','rejected'],true)){adminResponse(['success'=>false,'message'=>'Invalid payment status.'],422);} $s=$pdo->prepare('UPDATE bookings SET payment_status=? WHERE id=?'); $s->execute([$ps,$id]); } if(isset($d['status'])){ $st=cleanString($d['status']); if(!in_array($st,['pending','confirmed','completed','cancelled'],true)){adminResponse(['success'=>false,'message'=>'Invalid booking status.'],422);} $s=$pdo->prepare('UPDATE bookings SET status=? WHERE id=?'); $s->execute([$st,$id]); } if(isset($d['payment_status']) && !empty($booking['user_id'])) notifyUser($pdo,(int)$booking['user_id'],'Booking payment updated','Your M-Pesa payment status for booking #'.$id.' is now '.cleanString($d['payment_status']).'.','booking'); if(isset($d['status']) && !empty($booking['user_id'])) notifyUser($pdo,(int)$booking['user_id'],'Booking status updated','Your appointment #'.$id.' is now '.cleanString($d['status']).'.','booking'); adminResponse(['success'=>true]);}
if($method==='DELETE'){ $s=$pdo->prepare("DELETE FROM bookings WHERE id=?");$s->execute([(int)($d['id']??0)]);adminResponse(['success'=>true]);}
adminResponse(['success'=>false,'message'=>'Method not allowed'],405);
