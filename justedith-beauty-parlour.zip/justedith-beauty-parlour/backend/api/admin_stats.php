<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/admin.php';
requireAdmin();
function adminResponse($data, $code=200) {
  http_response_code($code); echo json_encode($data); exit;
}
function body() { return getJsonBody(); }

$stats=$pdo->query("SELECT
 (SELECT COUNT(*) FROM bookings) total_bookings,
 (SELECT COUNT(*) FROM bookings WHERE status='pending') pending_bookings,
 (SELECT COUNT(*) FROM bookings WHERE status='confirmed') confirmed_bookings,
 (SELECT COUNT(*) FROM bookings WHERE appointment_date=CURDATE()) today_bookings,
 (SELECT COUNT(*) FROM contact_messages) messages,
 (SELECT COUNT(*) FROM (SELECT b.id, (SELECT cm.sender FROM chat_messages cm WHERE cm.booking_id=b.id ORDER BY cm.created_at DESC,cm.id DESC LIMIT 1) last_sender FROM bookings b WHERE EXISTS (SELECT 1 FROM chat_messages x WHERE x.booking_id=b.id)) chat_state WHERE last_sender='customer') unread_chats,
 (SELECT COUNT(*) FROM service_ratings WHERE COALESCE(approved,0)=0) pending_ratings,
 (SELECT COUNT(*) FROM service_ratings WHERE COALESCE(approved,0)=1) approved_ratings,
 (SELECT COUNT(*) FROM orders) total_orders,
 (SELECT COUNT(*) FROM orders WHERE status='pending') pending_orders,
 (SELECT COUNT(*) FROM orders WHERE status IN ('completed','delivered')) completed_orders,
 (SELECT COALESCE(AVG(rating),0) FROM service_ratings WHERE COALESCE(approved,0)=1) avg_rating")->fetch();
adminResponse(['success'=>true,'stats'=>$stats]);
