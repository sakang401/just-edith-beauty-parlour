import React, { useEffect, useState } from 'react';
import { getProviderConversations, getProviderMessages, replyToChat } from './providerApi';
import { mediaUrl } from './api';

export default function ProviderApp() {
  const [pin, setPin] = useState(sessionStorage.getItem('justedith_provider_pin') || '');
  const [authenticated, setAuthenticated] = useState(false);
  const [conversations, setConversations] = useState([]);
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [reply, setReply] = useState('');
  const [status, setStatus] = useState('');

  async function loadConversations(currentPin = pin) {
    const data = await getProviderConversations(currentPin);
    setConversations(data.conversations || []);
    setAuthenticated(true);
    setStatus('');
  }

  async function login(e) {
    e.preventDefault();
    try {
      await loadConversations(pin);
      sessionStorage.setItem('justedith_provider_pin', pin);
    } catch (err) {
      setStatus(err.message);
      setAuthenticated(false);
    }
  }

  useEffect(() => {
    if (pin) loadConversations(pin).catch(() => setAuthenticated(false));
  }, []);

  async function openConversation(conversation) {
    setSelected(conversation);
    try {
      const data = await getProviderMessages(pin, conversation.id);
      setMessages(data.messages || []);
    } catch (err) { setStatus(err.message); }
  }

  async function sendReply(e) {
    e.preventDefault();
    if (!selected || !reply.trim()) return;
    try {
      await replyToChat(pin, selected.id, reply.trim());
      setReply('');
      await openConversation(selected);
      await loadConversations(pin);
    } catch (err) { setStatus(err.message); }
  }

  if (!authenticated) {
    return <div className="provider-page"><div className="provider-login"><p className="eyebrow">JUST EDITH · PRIVATE AREA</p><h1>Provider <em>Inbox</em></h1><p>Enter the provider PIN to access private customer conversations.</p><form onSubmit={login}><input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="Provider PIN" required/><button className="primary-btn" type="submit">Open Inbox</button></form>{status && <p className="form-status">{status}</p>}<a href="/">← Back to website</a></div></div>;
  }

  return <div className="provider-page">
    <div className="provider-header"><div><p className="eyebrow">JUST EDITH BEAUTY PARLOUR</p><h1>Private <em>Chat Inbox</em></h1></div><button className="ghost-btn" onClick={() => { sessionStorage.removeItem('justedith_provider_pin'); setAuthenticated(false); }}>Log out</button></div>
    <div className="provider-grid">
      <aside className="conversation-list"><h3>Customer conversations</h3>{conversations.length === 0 && <p className="muted">No customer chats yet.</p>}{conversations.map(c => <button className={selected?.id === c.id ? 'conversation active' : 'conversation'} key={c.id} onClick={() => openConversation(c)}><b>{c.name}</b><span>{c.service} · #{c.id}</span><small>{c.message_count} message(s)</small></button>)}</aside>
      <section className="provider-chat"><div className="chat-head">{selected ? <><b>{selected.name}</b><span>{selected.service} · Appointment {selected.appointment_date} at {selected.appointment_time}</span></> : <span>Select a conversation</span>}</div><div className="messages">{messages.map(m => <div key={m.id} className={m.sender === 'provider' ? 'bubble provider-bubble' : 'bubble customer-bubble'}><small>{m.sender === 'provider' ? 'You' : selected?.name}</small>{m.message && <p>{m.message}</p>}{m.image_path && <img src={mediaUrl(m.image_path)} alt="Customer style reference"/>}<time>{new Date(m.created_at).toLocaleString()}</time></div>)}</div>{selected && <form className="chat-reply" onSubmit={sendReply}><textarea value={reply} onChange={e => setReply(e.target.value)} placeholder="Reply to the customer…" rows="3" required/><button className="primary-btn" type="submit">Send Reply ✦</button></form>}{status && <p className="form-status">{status}</p>}</section>
    </div>
  </div>;
}
