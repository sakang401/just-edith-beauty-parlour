<?php
require_once __DIR__ . '/../config/cors.php'; require_once __DIR__ . '/../config/db.php'; require_once __DIR__ . '/../config/admin.php'; requireAdmin();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);exit;}
if(!isset($_FILES['image'])||$_FILES['image']['error']!==UPLOAD_ERR_OK){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Please select an image.']);exit;}
$f=$_FILES['image'];if($f['size']>8*1024*1024){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Image must be 8MB or smaller.']);exit;}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];if(!isset($allowed[$mime])){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Only JPG, PNG or WebP images are allowed.']);exit;}
$dir=__DIR__.'/../uploads/home/';$base='/justedith-beauty-parlour/backend/uploads/home/';if(!is_dir($dir))mkdir($dir,0777,true);
try{$q=$pdo->prepare("SELECT setting_value FROM store_settings WHERE setting_key='home_background'");$q->execute();$old=$q->fetchColumn();if($old){$oldFile=__DIR__.'/..'.parse_url($old,PHP_URL_PATH);if(is_file($oldFile))@unlink($oldFile);}}catch(Throwable $e){}
$name='home-'.bin2hex(random_bytes(8)).'.'.$allowed[$mime];move_uploaded_file($f['tmp_name'],$dir.$name);$url=$base.$name;$s=$pdo->prepare("INSERT INTO store_settings(setting_key,setting_value) VALUES('home_background',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$s->execute([$url]);echo json_encode(['success'=>true,'image_url'=>$url]);
?>