<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
try {
 $stmt=$pdo->query("SELECT id,title,image_url,category,sale_price,original_price,is_on_sale,created_at FROM style_photos ORDER BY created_at DESC");
 $photos=$stmt->fetchAll();
} catch(PDOException $e) {
 $stmt=$pdo->query("SELECT id,title,image_url,created_at FROM style_photos ORDER BY created_at DESC");$photos=$stmt->fetchAll();foreach($photos as &$p){$p['category']='Style';$p['sale_price']=0;$p['original_price']=null;$p['is_on_sale']=1;}
}
$settings=[];try{$rows=$pdo->query("SELECT setting_key,setting_value FROM store_settings")->fetchAll();foreach($rows as $r)$settings[$r['setting_key']]=$r['setting_value'];}catch(Throwable $e){}
$settings+=['sale_header_title'=>'Braids and Wigs on Sale','sale_header_subtitle'=>'Style your look today'];
echo json_encode(['success'=>true,'photos'=>$photos,'settings'=>$settings]);
?>