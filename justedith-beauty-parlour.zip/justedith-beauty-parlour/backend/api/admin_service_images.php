<?php
require_once __DIR__ . '/../config/cors.php'; require_once __DIR__ . '/../config/db.php'; require_once __DIR__ . '/../config/admin.php'; requireAdmin();
$dir=__DIR__.'/../uploads/services/'; $base='/justedith-beauty-parlour/backend/uploads/services/'; if(!is_dir($dir)) mkdir($dir,0777,true);
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);exit;}
$id=(int)($_POST['service_id']??0); if(!$id || !isset($_FILES['image']) || $_FILES['image']['error']!==UPLOAD_ERR_OK){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Service and image are required.']);exit;}
$f=$_FILES['image']; if($f['size']>5*1024*1024){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Image must be 5MB or smaller.']);exit;}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']); $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']; if(!isset($allowed[$mime])){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Only JPG, PNG or WebP images are allowed.']);exit;}
$old=$pdo->prepare('SELECT image_url FROM services WHERE id=?');$old->execute([$id]);$row=$old->fetch(); if(!$row){http_response_code(404);echo json_encode(['success'=>false,'message'=>'Service not found.']);exit;}
if(!empty($row['image_url'])){$oldFile=__DIR__.'/..'.parse_url($row['image_url'],PHP_URL_PATH);if(is_file($oldFile))@unlink($oldFile);}
$name=bin2hex(random_bytes(8)).'.'.$allowed[$mime]; move_uploaded_file($f['tmp_name'],$dir.$name); $url=$base.$name;
$pdo->prepare('UPDATE services SET image_url=? WHERE id=?')->execute([$url,$id]); echo json_encode(['success'=>true,'image_url'=>$url]);
?>