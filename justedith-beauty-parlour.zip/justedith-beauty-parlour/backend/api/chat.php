<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notify.php';

function findBooking(PDO $pdo, int $bookingId, string $token): ?array {
    $stmt = $pdo->prepare("SELECT id, name, service FROM bookings WHERE id = ? AND chat_token = ? LIMIT 1");
    $stmt->execute([$bookingId, $token]);
    $row = $stmt->fetch();
    return $row ?: null;
}

$bookingId = (int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
$token = cleanString($_GET['token'] ?? $_POST['token'] ?? '');

if ($bookingId < 1 || strlen($token) < 32) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'A valid booking ID and private chat token are required.']);
    exit;
}

$booking = findBooking($pdo, $bookingId, $token);
if (!$booking) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Private chat access denied. Check your booking details.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare("SELECT id, sender, message, image_path, created_at FROM chat_messages WHERE booking_id = ? ORDER BY created_at ASC");
    $stmt->execute([$bookingId]);
    echo json_encode(['success' => true, 'booking' => $booking, 'messages' => $stmt->fetchAll()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$message = cleanString($_POST['message'] ?? '');
$imagePath = null;

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'The image upload failed.']);
        exit;
    }

    if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Image must be 5MB or smaller.']);
        exit;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($_FILES['image']['tmp_name']);
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif'
    ];

    if (!isset($allowed[$mime])) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Please upload a JPG, PNG, WEBP or GIF image.']);
        exit;
    }

    $uploadDir = __DIR__ . '/../uploads/chat/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Could not create the upload folder.']);
        exit;
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Could not save the image. Check folder permissions.']);
        exit;
    }
    $imagePath = '/justedith-beauty-parlour/backend/uploads/chat/' . $filename;
}

if ($message === '' && $imagePath === null) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Type a message or attach an image first.']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO chat_messages (booking_id, sender, message, image_path) VALUES (?, 'customer', ?, ?)");
$stmt->execute([$bookingId, $message !== '' ? $message : null, $imagePath]);
$uid = (int)($pdo->query("SELECT user_id FROM bookings WHERE id=".(int)$bookingId)->fetchColumn());
notifyAdmin($pdo, 'New customer chat', 'New message from '.$booking['name'].' in booking #'.$bookingId.'.', 'chat');

echo json_encode(['success' => true, 'message' => 'Message sent.', 'message_id' => $pdo->lastInsertId()]);
?>
