import React, { useState } from 'react';
import { registerUser, loginUser } from './api';

export function RegisterPage({ onSuccess }) {
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', password: '', profile_image: null });
  const [status, setStatus] = useState('');

  async function submit(e) {
    e.preventDefault();
    setStatus('Creating your account…');
    const data = new FormData();
    Object.entries(form).forEach(([k,v]) => { if (v !== null) data.append(k, v); });
    data.append('action', 'register');
    try {
      const result = await registerUser(data);
      setStatus('✨ Account created. Welcome to Just Edith!');
      onSuccess(result.user);
    } catch (error) {
      setStatus(error.message);
    }
  }

  return <AuthShell title="Create your Just Edith account" subtitle="Save your beauty details, book appointments and keep your private style chat in one place.">
    <form className="auth-form" onSubmit={submit}>
      <div className="avatar-preview">{form.profile_image ? <img src={URL.createObjectURL(form.profile_image)} alt="Profile preview" /> : <span>JE</span>}</div>
      <label className="auth-file-picker"><span>Choose profile photo</span><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => setForm({...form, profile_image: e.target.files?.[0] || null})} required /></label>
      <div className="auth-grid">
        <label>Full name<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} required placeholder="Your full name" /></label>
        <label>Phone number<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required placeholder="07XX XXX XXX" /></label>
      </div>
      <label>Email address<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required placeholder="you@example.com" /></label>
      <label>Password<input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required minLength="8" placeholder="At least 8 characters" /></label>
      <button className="primary-btn wide" type="submit">Create Account ✦</button>
      {status && <p className="form-status">{status}</p>}
      <p className="auth-switch">Already have an account? <a href="/login">Log in</a></p>
    </form>
  </AuthShell>;
}

export function LoginPage({ onSuccess }) {
  const [form, setForm] = useState({ email: '', password: '' });
  const [status, setStatus] = useState('');

  async function submit(e) {
    e.preventDefault();
    setStatus('Signing you in…');
    const data = new FormData();
    data.append('action', 'login');
    data.append('email', form.email);
    data.append('password', form.password);
    try {
      const result = await loginUser(data);
      onSuccess(result.user);
    } catch (error) {
      setStatus(error.message);
    }
  }

  return <AuthShell title="Welcome back" subtitle="Log in to book your next beauty moment and manage your Just Edith appointments.">
    <form className="auth-form" onSubmit={submit}>
      <label>Email address<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required placeholder="you@example.com" /></label>
      <label>Password<input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required placeholder="Your password" /></label>
      <button className="primary-btn wide" type="submit">Log In ✦</button>
      {status && <p className="form-status">{status}</p>}
      <p className="auth-switch">New to Just Edith? <a href="/register">Create an account</a></p>
    </form>
  </AuthShell>;
}

function AuthShell({ title, subtitle, children }) {
  return <div className="auth-page">
    <div className="auth-brand"><a href="/"><img src="/logo.png" alt="Just Edith Beauty Parlour" /></a></div>
    <div className="auth-panel">
      <p className="eyebrow">JUST EDITH BEAUTY PARLOUR</p>
      <h1>{title}</h1>
      <p>{subtitle}</p>
      {children}
    </div>
  </div>;
}
