<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../config/admin.php'; requireAdmin();
function out($d,$c=200){http_response_code($c);echo json_encode($d);exit;}
try{$pdo->exec("ALTER TABLE users ADD COLUMN approved TINYINT(1) NOT NULL DEFAULT 0");}catch(Throwable $e){}
$m=$_SERVER['REQUEST_METHOD']; $d=getJsonBody();
if($m==='GET'){ $rows=$pdo->query("SELECT u.id,u.full_name,u.email,u.phone,u.created_at,u.approved,COUNT(b.id) bookings FROM users u LEFT JOIN bookings b ON b.user_id=u.id GROUP BY u.id,u.full_name,u.email,u.phone,u.created_at,u.approved ORDER BY u.created_at DESC")->fetchAll(); out(['success'=>true,'customers'=>$rows]); }
if($m==='POST'){ $name=cleanString($d['full_name']??'');$email=cleanString($d['email']??'');$phone=cleanString($d['phone']??''); if(!$name||!$email||!$phone)out(['success'=>false,'message'=>'Name, email and phone are required.'],422); $pass=password_hash($d['password']??bin2hex(random_bytes(8)),PASSWORD_DEFAULT);$s=$pdo->prepare('INSERT INTO users(full_name,email,phone,password_hash,approved) VALUES(?,?,?,?,1)');$s->execute([$name,$email,$phone,$pass]);out(['success'=>true,'id'=>$pdo->lastInsertId()]); }
if($m==='PUT'){ $id=(int)($d['id']??0);if($id<1)out(['success'=>false,'message'=>'Valid customer ID required.'],422); if(array_key_exists('approved',$d)){ $pdo->prepare('UPDATE users SET approved=? WHERE id=?')->execute([(int)!!$d['approved'],$id]);out(['success'=>true]); } $s=$pdo->prepare('UPDATE users SET full_name=?,email=?,phone=? WHERE id=?');$s->execute([cleanString($d['full_name']??''),cleanString($d['email']??''),cleanString($d['phone']??''),$id]);out(['success'=>true]); }
if($m==='DELETE'){ $id=(int)($d['id']??0);$pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);out(['success'=>true]); }
out(['success'=>false,'message'=>'Method not allowed'],405);
