<?php
function notifyUser(PDO $pdo, int $userId, string $title, string $message, string $type='general'): void {
  $s=$pdo->prepare("INSERT INTO notifications(user_id,audience,title,message,type) VALUES(?,?,?,?,?)");
  $s->execute([$userId,'user',$title,$message,$type]);
}
function notifyAdmin(PDO $pdo, string $title, string $message, string $type='general'): void {
  $s=$pdo->prepare("INSERT INTO notifications(user_id,audience,title,message,type) VALUES(NULL,'admin',?,?,?)");
  $s->execute([$title,$message,$type]);
}
