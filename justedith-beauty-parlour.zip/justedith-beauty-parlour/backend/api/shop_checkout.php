<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/notify.php'; session_start();
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'message'=>'Please log in to checkout.']);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);exit;}
$d=json_decode(file_get_contents('php://input'),true)?:[];$items=$d['items']??[];$method=$d['payment_method']??'';
if($method!=='mpesa'||!is_array($items)||!count($items)){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Select products and a payment method.']);exit;}
$uid=(int)$_SESSION['user_id'];$pdo->beginTransaction();
try{
 $subtotal=0;$clean=[];
 foreach($items as $item){$id=(int)($item['id']??0);$qty=max(1,min(99,(int)($item['quantity']??1)));$s=$pdo->prepare("SELECT id,title,sale_price,buying_price,original_price,is_on_sale FROM style_photos WHERE id=?");$s->execute([$id]);$p=$s->fetch();if(!$p)throw new Exception('One of the selected styles is no longer available.');$price=(float)$p['sale_price'];if($price<=0)$price=(float)($p['original_price']??0);if($price<=0)throw new Exception('A selected style does not have a sale price.');$subtotal += $price*$qty;$cost=(float)($p['buying_price']??0);$clean[]=[$p,$price,$qty,$cost];}
 $paymentStatus='pending';$receipt=trim((string)($d['mpesa_receipt']??''));$ref=trim((string)($d['payment_reference']??''));
 if($method==='mpesa' && $receipt==='')throw new Exception('Enter your M-Pesa transaction code.');
 $s=$pdo->prepare("INSERT INTO orders(user_id,subtotal,total_amount,payment_method,payment_status,mpesa_receipt,payment_reference) VALUES(?,?,?,?,?,?,?)");$s->execute([$uid,$subtotal,$subtotal,$method,$paymentStatus,$method==='mpesa'?$receipt:null,null]);$orderId=(int)$pdo->lastInsertId();
 foreach($clean as [$p,$price,$qty,$cost]){$s=$pdo->prepare('INSERT INTO order_items(order_id,style_photo_id,title,unit_price,unit_cost,quantity) VALUES(?,?,?,?,?,?)');$s->execute([$orderId,$p['id'],$p['title'],$price,$cost,$qty]);}

 notifyUser($pdo,$uid,'Order placed','Your order #'.$orderId.' for KSh '.number_format($subtotal,2).' was placed using M-PESA. Payment is pending verification.','order');
 notifyAdmin($pdo,'New store order','Order #'.$orderId.' was placed for KSh '.number_format($subtotal,2).' via '.strtoupper($method).'.','order');
 $pdo->commit();echo json_encode(['success'=>true,'order_id'=>$orderId,'total'=>$subtotal,'payment_status'=>$paymentStatus]);
}catch(Throwable $e){$pdo->rollBack();http_response_code(422);echo json_encode(['success'=>false,'message'=>$e->getMessage()]);}
