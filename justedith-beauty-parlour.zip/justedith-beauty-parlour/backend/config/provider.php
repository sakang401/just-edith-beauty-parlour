<?php
require_once __DIR__ . '/cors.php';
$PROVIDER_PIN = '1234';
function requireProvider(): void {
    global $PROVIDER_PIN;
    $pin = $_SERVER['HTTP_X_PROVIDER_PIN'] ?? '';
    if (!hash_equals($PROVIDER_PIN, $pin)) {
        http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Provider authentication required.']);
        exit;
    }
}
?>
