<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
echo json_encode(['success'=>true,'php'=>PHP_VERSION,'database'=>'connected']);
?>
