<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../config/admin.php'; requireAdmin();
if($_SERVER['REQUEST_METHOD']==='GET'){$rows=$pdo->query("SELECT setting_key,setting_value FROM store_settings")->fetchAll();$settings=[];foreach($rows as $r)$settings[$r['setting_key']]=$r['setting_value'];echo json_encode(['success'=>true,'settings'=>$settings]);exit;}
if($_SERVER['REQUEST_METHOD']==='PUT'){$d=json_decode(file_get_contents('php://input'),true)?:[];$allowed=['sale_header_title','sale_header_subtitle','home_background'];foreach($allowed as $key){if(isset($d[$key])){$s=$pdo->prepare("INSERT INTO store_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$s->execute([$key,trim((string)$d[$key])]);}}echo json_encode(['success'=>true]);exit;}
http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);
