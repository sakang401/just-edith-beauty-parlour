<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
try {
 $rows=$pdo->query("SELECT category,name,price,price_label,description,image_url,active FROM services WHERE active=1 ORDER BY category,name")->fetchAll();
 echo json_encode(['success'=>true,'services'=>$rows]);
} catch (Throwable $e) {
 $services=[
 ['category'=>'Braids & Twists','name'=>'Knotless Braids','price'=>600,'price_label'=>'KSh 600','note'=>'Classic, neat and effortlessly chic.'],
 ['category'=>'Braids & Twists','name'=>'Boho Knotless','price'=>600,'price_label'=>'From KSh 600','note'=>'Soft curls, texture and luxe movement.'],
 ['category'=>'Braids & Twists','name'=>'Boho Twists','price'=>1000,'price_label'=>'From KSh 1,000','note'=>'Statement twists with a beautiful finish.'],
 ['category'=>'Braids & Twists','name'=>'Coco Twists','price'=>800,'price_label'=>'From KSh 800','note'=>'Polished protective styling with attitude.'],
 ['category'=>'Lashes','name'=>'Classic','price'=>400,'price_label'=>'KSh 400','note'=>'Natural definition for everyday glam.'],
 ['category'=>'Lashes','name'=>'Hybrid','price'=>700,'price_label'=>'KSh 700','note'=>'The perfect balance of soft and bold.'],
 ['category'=>'Lashes','name'=>'Volume','price'=>1000,'price_label'=>'KSh 1,000','note'=>'Fuller, dramatic and unapologetically luxe.'],
 ['category'=>'Lashes','name'=>'Lash Removal','price'=>100,'price_label'=>'KSh 100','note'=>'Gentle, careful removal.']];
 echo json_encode(['success'=>true,'services'=>$services]);
}
?>