<?php
require_once __DIR__.'/../config/cors.php'; require_once __DIR__.'/../config/db.php'; session_start();
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['success'=>false,'message'=>'Please log in.']);exit;}
$uid=(int)$_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD']==='GET'){
 $s=$pdo->prepare('SELECT wallet_balance FROM users WHERE id=?');$s->execute([$uid]);$balance=(float)$s->fetchColumn();
 $s=$pdo->prepare('SELECT type,amount,description,reference,created_at FROM wallet_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 30');$s->execute([$uid]);
 echo json_encode(['success'=>true,'balance'=>$balance,'transactions'=>$s->fetchAll()]);exit;
}
http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method not allowed']);
