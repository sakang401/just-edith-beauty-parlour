const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost/justedith-beauty-parlour/backend/api';

async function providerRequest(path, pin, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}/${path}`, {
      ...options,
      headers: {
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        'X-Provider-Pin': pin,
        ...(options.headers || {}),
      },
    });
  } catch {
    throw new Error('Cannot reach the PHP server. Start Apache in XAMPP and keep the React dev server running.');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Server error (${response.status})`);
  return data;
}

export const getProviderConversations = (pin) => providerRequest('provider_chat.php', pin);
export const getProviderMessages = (pin, bookingId) => providerRequest(`provider_chat.php?booking_id=${encodeURIComponent(bookingId)}`, pin);
export const replyToChat = (pin, bookingId, message) => providerRequest('provider_chat.php', pin, {
  method: 'POST',
  body: JSON.stringify({ booking_id: bookingId, message }),
});
