<?php
require_once __DIR__ . '/admin_common.php';
// Add reply fields for existing installations without requiring a manual migration.
foreach ([
  'ALTER TABLE contact_messages ADD COLUMN admin_reply TEXT NULL',
  'ALTER TABLE contact_messages ADD COLUMN replied_at TIMESTAMP NULL DEFAULT NULL'
] as $sql) { try { $pdo->exec($sql); } catch (Throwable $e) {} }
$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){
  $rows=$pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();
  adminResponse(['messages'=>$rows]);
}
if($method==='PUT'){
  $d=body(); $id=(int)($d['id']??0); $reply=cleanString($d['reply']??'');
  if(!$id || $reply==='') adminResponse(['message'=>'A reply is required'],422);
  $pdo->prepare('UPDATE contact_messages SET admin_reply=?, replied_at=NOW() WHERE id=?')->execute([$reply,$id]);
  adminResponse(['success'=>true]);
}
if($method==='DELETE'){ $d=body(); $id=(int)($d['id']??0); $pdo->prepare('DELETE FROM contact_messages WHERE id=?')->execute([$id]); adminResponse(['success'=>true]); }
adminResponse(['message'=>'Method not allowed'],405);
